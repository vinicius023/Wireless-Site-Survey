# INTRODUÇÃO


*Wireless Survey* é uma forma de inspeção de rede sem fio através da
análise da intensidade de sinal Wi-Fi de determinada área ou WLAN
específica. A medição é feita pelo canal da banda de frequência, de
acordo com o padrão Wi-Fi considerado (2.4 GHz no caso do IEEE 802.11
b/g/n ou 5 GHz no 802.11 a/ac).

Com os dados coletados por uma ferramenta de *wireless survey* é
possível analisar um melhor posicionamento para os pontos de acesso
(APs) à rede sem fio levando em conta os locais de maior interferência
de sinal observados. Também é possível verificar se é necessário o
acréscimo do número de APs. O sinal Wi-Fi pode sofrer interferência de
qualquer produto capaz de emitir sinais de RF na mesma faixa de
frequência do ponto de acesso que o emite. Geralmente isso ocorre quando
algum equipamento também está em uma frequência de 2.4 GHz (ou 5.8 GHz,
conforme o caso).

A aplicação deste método de análise é cabível quando é notado que a rede
Wi-Fi em uso apresenta baixa qualidade no canal e/ou queda de desempenho
da rede, sem que esta seja causada pelo uso massivo de usuários da rede
em questão. O *wireless survey* também é muito utilizado no planejamento
de uma nova rede Wi-Fi, por exemplo, evitando-se locais com
preexistência de APs trabalhando na mesma frequência.

Nas seções a seguir serão apresentados os objetivos e justificativas
deste projeto, bem como a metodologia para o desenvolvimento de uma
aplicação *wireless survey* gratuita e de código fonte aberto, com
suporte ao sistema operacional GNU/Linux.

## Justificativa

O site *survey* (ou *wireless survey*) é muito importante no projeto de
uma rede sem fio. Com ele é possível determinar e antecipar possíveis
pontos de falha na cobertura de uma rede Wi-Fi, diagnosticar áreas de
sombra, de interferências de sinal e determinar a melhor localização dos
pontos de acesso (APs), assim como o melhor modelo e potência mais
adequados. Além disso serve como uma certificação para o ambiente onde a
rede *wireless* será instalada.

O intuito da realização deste trabalho é disponibilizar para a
comunidade acadêmica e externa uma ferramenta capaz de realizar medições
com precisão e sem limitações na coleta da intensidade de sinal Wi-Fi,
para ser usado em suas instituições/empresas, mostrando de forma simples
e intuitiva os possíveis locais com deficiência de cobertura de sinal
Wi-Fi.

De posse do relatório de inspeção gerado pela ferramenta, o responsável
pela rede poderá promover mudanças que visem a sanar tais deficiências.
Porém esta aplicação não se limita ao uso em apenas empresas ou
instituições, ela poderá também ser utilizada por usuário residencial
que tenha interesse em encontrar uma posição mais eficiente para seu (s)
ponto (s) de acesso (APs).

Como as tecnologias Wi-Fi (802.11) têm se popularizado e estão cada vez
mais integradas à comunidade em geral, uma ferramenta para inspeção de
redes sem fio será bem vinda.

Até o momento da pesquisa não foi encontrado uma ferramenta com suporte
para os Sistemas Operacionais GNU/Linux, apenas recursos de bash já
presentes no SO, como por exemplo *iwlist*.

## Objetivos 

O objetivo geral deste trabalho de conclusão de curso é desenvolver um
software livre de código-fonte aberto (FOSS) para conduzir um *Wireless
Site Survey*, ou seja, uma avaliação dos sinais Wi-Fi providos por um ou
mais AP *wireless* (pontos de acesso) em determinado local, através de
medições das características dos sinais e sua posição no plano,
fornecendo uma representação gráfica dos resultados sobreposta ao plano
do local.

### Objetivos Específicos

-   Criar um software livre para medição de características dos sinais 
Wi-Fi (ex.: intensidade do sinal, qualidade do sinal, frequência e
canal, ESSID da rede, endereço MAC do AP, padrões Wi-Fi suportados
e taxas de bits);

-   Fornecer mecanismo prático para marcação da posição medida no plano
do edifício (ex.: planta-baixa, sketch), sendo este fornecido como
entrada ao software;

-   Prover uma visualização gráfica das características dos sinais
Wi-Fi, através de mapa de calor (*heatmap*) ou similar, no
relatório de saída e/ou durante as medições;

-   Disponibilizar o software gratuitamente, livre e com código-fonte
aberto (FOSS), com suporte inicial a sistemas operacionais
GNU/Linux.

# FUNDAMENTAÇÃO TEÓRICA

## Padrões Wi-Fi (IEEE 802.11)

Segundo Tay e Chua, devido ao constante crescimento de dispositivos
móveis, a expansão de recursos computacionais e a popularização do
acesso à internet, há uma necessidade constante destes computadores
serem interligados em rede (TAY e CHUA, 2001). Levando isso em conta
surgiu o padrão IEEE 802.11 para redes sem fio locais, desenvolvido por
um grupo de estudos da IEEE (IEEE 802.11-2016). Neste padrão são
definidas as características da camada física, bem como os protocolos de
controle de acesso ao meio (MAC) na camada de enlace.

Uma rede local sem fio (WLAN) possui como principal característica
transmitir sinal sem fio através de ondas de radiofrequência e existe um
fator decisivo que divide o padrão IEEE 802.11 em duas classes: a faixa
de frequência. Há padrões que operam a 2.4 GHz e outros com 5 GHz. Há de
se considerar a questão da diferença de alcance do sinal, uma vez que
seria gasta uma quantidade maior de energia para transmitir sinais com
uma alta frequência a uma mesma distância. Portanto, reduz-se o alcance
esperado dos sinais de 5 GHz para que seja mantido o patamar de consumo
energético.

Tais faixas de frequência consistem em uma fatia do espectro de
radiofrequência que pode ser utilizado para finalidades de WLAN. Tal
fatia é subdividida a cada em canais, para que seja possível haver mais
de um ponto de acesso (AP) à rede sem fio. A Figura \ref{canaisWiFi2} ilustra a
divisão de canais realizada na faixa de frequência de 2,4 GHz, utilizada
por equipamentos Wi-Fi 802.11b/g/n.


![Lista de canais disponíveis para a tecnologia Wi-Fi 2.4 GHz](imagens/canaisWiFi2.png){#canaisWiFi2 width="5.065252624671916in" height="1.73665791776028in"}

Fonte: \url{http://directnetbroadband.com}


![Lista de canais disponíveis para a tecnologia Wi-Fi 5 GHz](imagens/canaisWiFi5.png){#canaisWiFi5 width="4.3048862642169725in" height="2.1664501312335958in"}

Fonte: \url{https://meraki.cisco.com}

Já a Figura \ref{canaisWiFi5} mostra a divisão de canais realizada na faixa de
frequência de 5 GHz, utilizada por equipamentos Wi-Fi 802.11a/ac. Além
da diferença de faixa de frequência, os padrões Wi-Fi IEEE 802.11 (b/g/n
e a/ac) diferem na taxa de transmissão de dados e alcance.

A Tabela \ref{802.11} apresenta um resumo sobre as características dos principais
padrões IEEE 802.11 para rede local sem fio (WLAN).

\begin{table}[htb]
\ABNTEXfontreduzida
\centering
\caption{802.11 padrões da camada Física de Rede}
\label{802.11}
\resizebox{\textwidth}{!}{%
\begin{tabular}{|c|c|c|c|c|c|c|c|}
\hline
\multicolumn{8}{|c|}{\textbf{802.11 padrões da camada Física de Rede}} \\ \hline
{\textbf{Protocolo 802.11}} & \textbf{Frequência} & \textbf{Largura de banda} & \textbf{Bitrate} & {\textbf{MIMO}} & {\textbf{MAC}} & \multicolumn{2}{c|}{\textbf{Alcance Aproximado}} \\ \cline{2-4} \cline{7-8} 
 & \textbf{(GHz)} & \textbf{(MHz)} & \textbf{(Mbit/s)} &  &  & \textbf{Indoor (m)} & \textbf{Outdoor (m)} \\ \hline
802.11-1997 & 2.4 & 22 & 1, 2 & - & DSSS, FHSS & 20 & 100 \\ \hline
a & 5 & 20 & 6 - 54 & - & OFDM & 35 & 120 \\ \hline
b & 2.4 & 22 & 1 - 11 & - & DSSS & 35 & 140 \\ \hline
g & 2.4 & 20 & 6 - 54 & - & OFDM & 38 & 140 \\ \hline
{n} & {2.4} & 20 & 288.8 (72.2 por fluxo) & {Até 4 fluxos} & {\begin{tabular}[c]{@{}c@{}}MIMO-\\ OFDM\end{tabular}} & {70} & {250} \\ \cline{3-4}
 &  & 40 & 600 (150 por fluxo) &  &  &  &  \\ \cline{1-5} \cline{7-8} 
{ac} & {5} & 20 & Até 346.8 & {Até 8 fluxos} &  & {35} & {150} \\ \cline{3-4}
 &  & 40 & Até 800 &  &  &  &  \\ \cline{3-4}
 &  & 80 & Até 1733.2 &  &  &  &  \\ \cline{3-4}
 &  & 160 & Até 3466.8 &  &  &  &  \\ \hline
\end{tabular}%
}
\end{table}

Fonte: \url{https://en.wikipedia.org/wiki/IEEE_802.11}

Conforme pode ser observado na coluna MAC (Controle de Acesso ao Meio)
da Tabela \ref{802.11}, uma grande inovação na tecnologia Wi-Fi
surgiu com a utilização de múltiplos fluxos espectrais (tecnologia MIMO
- Múltiplas Entradas e Múltiplas Saídas) ao invés de apenas um. Com
isso, consegue-se uma maior taxa de dados, proporcional à quantidade de
fluxos MIMOs. Os padrões 802.11n e 802.11ac utilizam-se de MIMO para
alcançar taxas de dados de 2 a 8 vezes maiores do que antes era
possível.

Nos diferentes padrões Wi-Fi de 2,4 GHz, em virtude de uma maior ou
menor utilização da faixa de frequência disponível e de acordo com a
largura exigida pelo padrão, apenas de dois a quatro access points (APs)
podem coexistir em um mesmo ambiente sem interferir entre si, conforme
ilustra a Figura \ref{bXc}.

![Largura de banda vs utilização de canais Wi-Fi](imagens/bandaXcanal.png){#bXc width="3.993725940507437in"
height="2.4938593613298337in"}

Fonte: \url{https://en.m.wikipedia.org/wiki/File:NonOverlappingChannels2.4GHzWLAN-en.svg}

Já os padrões 802.11a/ac, por utilizarem a faixa de frequências de 5
GHz, maior e menos congestionada que 2,4 GHz, sofrem em menor grau com
interferências alheias, podendo alcançar taxas de bits/segundo maiores.
A Figura \ref{coexisteP} ilustra a grande diferença na quantidade de canais (com
coexistência) nas faixas de 2,4 GHz e 5 GHz.

![Coexistência de canais dos padrões Wi-Fi](imagens/coexistePadroes.png){#coexisteP width="5.355356517935258in"
height="1.310071084864392in"}

Fonte: \url{https://www.metageek.com}

## Propagação e Atenuação de Sinais de Rádio

A propagação de uma onda de rádio é feita isotropicamente a partir da
fonte de irradiação com raios dispersando em todas as direções. Um raio
está sujeito a três grandes fenômenos da física: dispersão/refração,
difração e reflexão, o que pode levar a perdas e atenuações do sinal
transmitido. Além destes fenômenos causadores de interferência, uma onda
está sujeita ao meio em que ela é propagada e as possíveis fontes de
ruído para o sinal, tais como cabeamento elétrico de alta intensidade ou
próximo ao transmissor, motores, metais, espelhos, concreto, entre
outras fontes. Estes obstáculos/fontes de ruídos podem absorver ou
refletir parcialmente o sinal de transmissão e continuar a propagar o
sinal atenuado (RAPPAPORT, 2009).

Assim, a opção pela utilização de uma frequência duas vezes mais alta
faz com que o comprimento de onda seja duas vezes menor, de maneira que
paredes, móveis e outros obstáculos passem a obstruir mais os sinais.
Tais obstáculos afetam as redes sem fio 802.11a/ac em maior grau do que
as redes 802.11 b/g comparáveis. Isso faz com que os sinais de Wi-Fi de
5 GHz fiquem mais "contidos" no ambiente devido ao seu alcance menor,
porém, gerando menos interferência em outros ambientes. A Figura \ref{alcancePadroes}
ilustra os diferentes alcances esperados para os padrões de rede sem fio
IEEE 802.11.

![Diferença de alcance dos padrões Wi-Fi](imagens/alcancePadroes.jpg){#alcancePadroes width="6.299212598425197in"
height="3.513888888888889in"}

Fonte: \url{http://najibkhalaf.com}

Outro ponto importante a ressaltar é que existe perda de sinal
proporcional a distância do receptor em relação ao transmissor: a
distância que um raio é capaz de alcançar está limitada a quantidade de
energia necessária para o transmissor conseguir enviar o sinal. Assim,
quanto maior a potência de transmissão maior será o alcance. Entretanto,
os órgãos reguladores como a FCC e ANATEL definem limites para a
quantidade de energia que pode ser irradiada pelos equipamentos de
transmissão. Assim, o sinal transmitido terá um alcance máximo de
recepção pelo fato de enfraquecer-se ao longo do trajeto, até que
alcance um nível de potência fraco demais para a sensibilidade do
equipamento receptor.

![Decaimento exponencial do sinal Wi-Fi recebido](imagens/modelosPropagacao.png){#modelosPropagacao width="6.302329396325459in"
height="3.9027777777777777in"}

Fonte: o Autor

A Figura \ref{modelosPropagacao} apresenta o decaimento da potência de sinal Wi-Fi ao longo
dos 100 metros do alcance previsto para WLANs. A curva azul representa
medições realizadas no campus, ao longo de um corredor de 20 metros. Já
a curva vermelha, ao longo de todos os 100 metros corresponde à previsão
de decaimento energético de um modelo de propagação de sinais de
radiofrequência, conhecido na literatura como LogDistance (RAPPAPORT,
2009). Observe que a 100 metros, o nível de sinal esperado seria menor
que -100 dBm, valor inferior à sensibilidade típica de -90 dBm de
equipamentos com suporte a Wi-Fi como *smartphones* e *notebooks*.

## Sistemas de *Wireless Site Survey*

*Wireless Survey* ou *Site Survey* é uma técnica que pode ser utilizada
para medir e visualizar os níveis de intensidade do sinal de rede local
sem fio (WLAN) nos diversos ambientes de um edifício. Segundo Santos,

*"Wireless Site Survey, é um conjunto de métodos aplicados na
avaliação técnica minuciosa do local de instalação de uma nova
infraestrutura de rede wireless, na observação dos resultados obtidos
das melhorias de uma infra-estrutura já utilizada ou, ainda, na
detecção e resolução de possíveis problemas em um sistema ativo. Esses
processos são efetuados, normalmente, durante o estudo de viabilidade
do projeto, seja no levantamento da infra-estrutura necessária ou na
instalação de uma nova rede estruturada, de equipamentos transmissores
de radiofreqüência e redes wireless".* (SANTOS, 2007)

Analisando o resultado de tal levantamento, a partir de uma visualização
gráfica das informações de sinal *wireless* é possível verificar os
ambientes que estão com boa cobertura de sinal Wi-Fi, bem como aqueles
que possuem níveis de sinal muito fracos ou mesmo zonas de sombra
(quando o sinal estiver abaixo da sensibilidade do equipamento).
Considere que,

*"Por meio da análise destes recursos é possível entender seu
comportamento, descobrir áreas cobertas, checar interferências de
radiofreqüência, indicar a disposição apropriada dos dispositivos
wireless, determinar o melhor aproveitamento do local estudado quanto
à cobertura e eficiência de sinais, bem como em relação à redução dos
custos de investimento".* (SANTOS, 2007).

Apesar de ser bem difundida na comunidade de TI, por vezes tal técnica
passa despercebida ao usuário leigo, na avaliação da cobertura de Wi-Fi
em instalações domésticas ou institucionais. Com uma representação
visual dos dados numéricos coletados (sobre a intensidade do sinal em
cada posição aferida), pode-se observar que existem muitas áreas de
sombra onde deveria haver cobertura de sinal Wi-Fi ou então que um único
*access point* (AP) centralizado proveja cobertura abrangente mas com
sinal muito fraco na periferia do pavimento de um edifício (ex.: sala de
professores no bloco A do campus Formiga). Nestes e em outros casos,
através dos resultados do *wireless survey* é possível tomar decisões
como aumentar o ganho das antenas (e consequentemente o alcance) dos
equipamentos já instalados ou, então, realizar um planejamento e compra
de mais equipamentos, aumentando a área coberta e sua qualidade de
sinal. Em seu trabalho sobre *Wireless Survey*, Santos afirma que:

*"Se um único AP não produzir cobertura suficiente para todos os
dispositivos da rede, uma quantidade de células (área de cobertura do
AP) pode ser adicionada para aumentar a abrangência da rede Wi-Fi. É
recomendado que os APs de uma mesma rede tenham de 10 a 15% de
sobreposição para permitir que usuários remotos transitem sem perda de
conexão e com garantia de cobertura de sinal de RF. Os APs que fazem
fronteira uns com os outros devem ser colocados em diferentes canais
de transmissão para obtenção de melhor desempenho, evitando
interferências intercanais".* (SANTOS, 2007).

## Categorias de *Site Survey*

O Site Survey é capaz de identificar possíveis zonas de
interferência/ruído presentes no local de avaliação por meio da análise
dos resultados obtidos em uma coleta, existem duas categorias de
avaliação:

*“**Indoor:** consiste em realizar a inspeção de redes wireless,
buscando interferências, localização de access points e disposição
geográfica de APs. Esse tipo de inspeção fornece gráficos de
intensidade de sinais, mais práticos de serem analisados, visto que as
pesquisas são realizadas em espaços relativamente pequenos. As fontes
de interferências são menores nesses ambientes, o que facilita a
escolha de antenas e dispositivos transmissores e receptores (GEIER,
2002).
>
**Outdoor:** consiste em realizar a inspeção de redes wireless em um
âmbito muito maior que o existente na modalidade indoor, por meio de
interferências mais complexas. Busca-se determinar a localização e
posição de access points e das antenas de transmissão de grande porte,
com base na disposição geográfica dos dispositivos e dos demais
aspectos de inspeção do site survey. Geralmente, é realizado em
projetos ou redes de grande porte que possuem diversas interligações
com diferentes redes localizadas em áreas distantes (GEIER, 2002).”*
(SANTOS, 2007).

Durante a avaliação do sinal Wi-Fi, informações que podem ser
consideradas importantes para análise dos resultados da medição
realizada são:

-   pontos de acesso (APs) - analisar se as posições dos transmissores
    de sinal estão de fato em uma localização que propicie boa
    intensidade e qualidade de sinal;

-   nomes das redes sem fio (SSID) - verificar se determinada rede tem
    uma boa cobertura na área em avaliação;

-   frequências utilizadas por cada AP - serve para identificar
    possíveis interferências entre pontos de acesso que estão
    transmitindo na mesma frequência;

-   em qual canal cada AP está operando - se um AP estaria transmitindo
    em uma mesma frequência que outro, causando interferência entre
    APs;

## Trabalhos relacionados
  
A Tabela \ref{compSiteSurvey} apresenta os softwares relacionados, para condução de
*Wireless Site Survey*. Observe que o software desenvolvido neste
trabalho de conclusão de curso (TCC) é gratuito, livre e de código-fonte
aberto (FOSS), grande diferencial em relação às soluções comerciais
disponíveis até então.

\begin{table}[htb]
\ABNTEXfontreduzida
\centering
\caption{Comparação aplicações de wireless site survey}
\label{compSiteSurvey}
\resizebox{\textwidth}{!}{%
\begin{tabular}{|c|c|c|c|}
\hline
\textbf{Produto} & \textbf{Sistema Operacional} & \textbf{Licença} & \textbf{Preço (Dólar \$)} \\ \hline
AirMagnet Survey & Windows & Proprietária & U\$ 3,447.00 \\ \hline
Ekahau Site Survey & Windows / MacOS (beta) & Proprietária & U\$ 2,295.00 \\ \hline
iBwave Wi-Fi® & Windows / Android & Proprietária & U\$ 1,495.00 \\ \hline
TamoGraph Site Survey & Windows & Proprietária & U\$ 899.00 \\ \hline
VisiWave Site Survey & Windows & Proprietária & U\$ 549.00 \\ \hline
NetSpot WiFi Site Survey & Windows / MacOS & Proprietária & U\$ 149.00*há versão gratuita para uso caseiro, no Windows \\ \hline
Meritech ISite & Windows & Proprietária & U\$ 495.00 \\ \hline
Software do autor, apresentado neste TCC & \textbf{GNU LINUX} & \textbf{LIVRE} & \textbf{GRATUITO} \\ \hline
\end{tabular}%
}
\end{table}

Fonte: \url{https://en.wikipedia.org/wiki/Comparison_of_wireless_site_survey_applications}

# METODOLOGIA

A seguir são destacados os principais passos que foram tomados para a
realização integral das especificações propostas deste TCC, seguindo o
método PDCA para iteração, controle e melhoria do processo de
desenvolvimento.

## Preparação e Projeto

### Coleta das medições

A primeira, e possivelmente, a mais importante etapa de
desenvolvimento foi na decisão de como seria feita a coleta dos dados
de sinais Wi-Fi, nesta fase foi decidido que estas informações seriam
obtidas por meio de uma ferramenta livre do Sistema Operacional Linux,
o *iwlist scannig*, antes outras abordagens foram testadas, mas devido
às informações oferecidas pelo *iwlist* serem de melhor interpretação
e análise este foi adotado para a coleta das medições. Para uma melhor
análise da saída, foi necessária a utilização de um script com os
filtros para descartar algumas informações de pouca ou nenhuma
relevância para a condução do *survey*.

![Exemplo de saída do software *iwlist*](imagens/saidaIwlist.png){#saidaIwlist width="5.006397637795276in"
height="2.6458333333333335in"}

Fonte: o Autor

### Visualização dos dados

Foram pesquisados métodos de visualização da intensidade do sinal
*wireless*, tais como, por exemplo, mapas de calor (*heat map*),
isolinhas (*countour line*) e gráficos de superfície (*surface plot*),
e para esta aplicação foi adotado o mapa de calor utilizando uma
biblioteca java para interação com o GNUPLOT por meio da interpolação
dos dados coletados e devidamente filtrados gera o heatmap.

Mesmo que não esteja disponível a posição no plano de cada medição
efetuada, um *heatmap* auxilia na visualização dos dados coletados,
conforme ilustram as Figuras XXX e YYY. A Figura XXX exibe a
visualização de um dos primeiros experimentos, realizado no corredor
do segundo pavimento do bloco A. As medições deste teste foram
realizadas em linha reta. Os dados foram filtrados para exibir a
intensidade de sinal (RSSI) de um único ponto de acesso (AP). Na
imagem, ambos os eixos x e y representam a ordem em que as medições
foram coletadas, de maneira que formam uma linha diagonal por ter o
mesmo valor em X e Y. Ainda assim, nota-se o decaimento da intensidade
do sinal Wi-Fi através do gradiente de cores gerado pelo GNUPLOT.
Observe que as “manchas escuras” no meio do gráfico representam fontes
de interferência do sinal que ocorreram durante a medição,
especificamente as portas (abertas ou fechadas) ao longo do corredor
em que o *survey* foi conduzido.

![*Heatmap* da intensidade do sinal (RSSI)](imagens/heatmapIntensidadeLembranca.png){#RSSI width="6.25in" height="3.4519356955380576in"}

Fonte: o Autor

![Heatmap da qualidade (SNR)](imagens/heatmapQualidadeLembranca.png){#SNR width="6.25in"
height="4.166666666666667in"}

Fonte: o Autor

![*Heatmap* da intensidade do sinal (RSSI) por medição (X,Y)](imagens/heatmapXY.png){#heatmapXY width="6.302329396325459in"
height="3.7777777777777777in"}

Fonte: o Autor

As cores escolhidas aqui servem para representar maior e menor
quantidade de sinal em uma determinada área, onde mais próximo da cor
vermelha representa um sinal mais forte/quente o que significa que
está mais perto ou recebendo uma maior intensidade de sinal do AP e
quanto mais próximo de azul representa um sinal mais fraco/frio, o que
significa que está mais distante ou sofre mais interferência na
recepção do sinal. Com este Heatmap então é possível interpretar a
imagem sobreposta a uma planta do local inspecionado ou avaliado em
questão, e relatar possíveis falhas no posicionamento dos roteadores
ou pontos de acesso sem fio e ainda sugerir um reposicionamento ou
reajuste (ex.: mudar a frequência ou canal em que o ap trabalha) para
os mesmos.

Outra informação importante que pode ser observada pela imagem é que a
diferença na coloração se dá em *decibel miliwatt* (dbm) e, muitas
vezes, esses valores parecem ter uma pequena diferença entre si quando
na verdade são ordens de grandeza. O decibel (dB) é uma unidade
logarítmica que indica a proporção de uma quantidade física
(geralmente energia ou intensidade) em relação a um nível de
referência especificado ou implícito. Uma relação em decibels é igual
a dez vezes o logaritmo de base 10 da razão entre duas quantidades de
energia.

Equação para conversão de dBm para Watts:

$P(W)\  = \ 1W\  \cdot \ 10(P(dBm)\ /\ 10)\ /\ 1000\  = \ 10((P(dBm) - \ 30)\ /\ 10)$

Tal diferença pode ser observada no exemplo abaixo, onde o valor do
sinal expresso por dBm é convertido em miliwatts (mW). Foram
convertidos os valores extremos do gráfico apresentado na Figura
anterior (-55 e -90 dBm).

-   $-55 dBm = 3,162\cdot 10^-9 W (watts)$ ou 0,**00000**3162 (mW);

-   $-90 dBm = 1,00\cdot 10^-12 W (watts)$ ou 0,**00000000**1 (mW);

## Implementação

### Interpretação dos dados coletados

A medição da intensidade do sinal e outras características é realizada
através de serviços do sistema operacional GNU/Linux, utilizando o
*iwlist* *scannig* e GNUPLOT. O *iwlist* é responsável pela coleta das
informações. Explicação de uma saída do *iwlist* como mostrada
anteriormente:

-   **Cell** 01 - **Address**: 18:8B:9D:69:EF:F6 -&gt; Ordem de
    aparecimento do AP na medição e seu endereço MAC;

-   **Channel**: 44 -&gt; O canal no qual o AP está atuando no momento
    da medição;

-   **Frequency**: 5.22 GHz (Channel 44) -&gt; Frequência de transmissão
    que o AP está utilizando;

-   **Quality**: 41 -&gt; O quanto o sinal recebido está mais forte que
    a interferência observada, ou seja, neste caso a relação de sinal
    para ruído (SNR) é de 41 vezes. Recentemente definido pelo IEEE
    802.11k como RSNI (*Received Signal to Noise Indicator*);

-   **Signal level**: -69 dBm -&gt; Intensidade de sinal recebida do
    Transmissor, conhecido como RSSI (*Received Signal Strength
    Indicator*) e mais recentemente definido pelo IEEE 802.11k como
    RCPI (*Received Channel Power Indicator*);

-   **Encryption key**: on -&gt; Indica se o AP possui algum tipo de
    criptografia ou não;

-   **ESSID**: "wifi-alunos" -&gt; Nome da rede anunciada pelo AP;

-   **Bit Rates**: 12 Mb/s; 18 Mb/s; 24 Mb/s; 36 Mb/s; 48 Mb/s -&gt;
    Taxas de transmissão suportadas pelo Ponto de Acesso;

-   **IE**: IEEE 802.11i/WPA2 Version 1 -&gt; Indica o padrão de
    criptografia utilizado;

Durante a coleta dos dados para cada ponto de medição é marcada uma
posição na tela que representa a posição em escala na planta carregada
na interface, ou seja, o lugar que estiver marcado por um ponto no mapa
representa o local real em que o usuário se encontra em relação a planta
do local de avaliação.

### Filtragem de dados da coleta

No *script* para filtrar[^1] do *iwlist* as informações relevantes, os
filtros escolhidos foram: endereço MAC do AP (Cell), canal (Channel),
frequência (Frequency), qualidade do sinal (Quality) e nome da rede
(ESSID).

\clearpage

![Filtragem da saída do *iwlist*](imagens/filtraIwlist.png){#filtraIwlist width=80%}

Fonte: o Autor

[^1]: Disponivel em: \url{https://github.com/vinicius023/Wireless-Site-Survey/blob/master/WirelessSurveyTCC/filtra-iwlist.sh}

A Figura \ref{filtraIwlist} exibe uma amostra das informações filtradas. Vale notar que
apesar de termos todas as informações salvas, algumas das informações
coletadas tais como taxas de bits, tipo de criptografia e protocolo de
segurança, não serão apresentados ao usuário como opções para filtrar os
dados para gerar o mapa de calor da coleta.

### Representação do ambiente 

Para a representação do ambiente a ser avaliado, é utilizado uma imagem
(JPEG ou PNG) como entrada. Esta imagem é carregada em memória e exibida
na interface gráfica para o usuário. A Figura \ref{ambienteInterface} ilustra a
representação gráfica do ambiente a ser analisado, dentro da interface
gráfica do software produzido neste TCC.

![Representação do ambiente na interface da aplicação](imagens/ambienteInterface.png){#ambienteInterface width="6.299212598425197in"
height="3.4166666666666665in"}

Fonte: o Autor

Foi estipulado que o tamanho do painel que irá exibir a planta-baixa do
edifício teria um valor fixo, de modo a evitar problemas que poderiam
ser causados por uma mudança de escala, para medições previamente
coletadas no mesmo ambiente.

A entrada fornecida pelo usuário (imagem) deverá ser uma representação
visual da planta baixa do ambiente a ser analisado. O motivo é facilitar
a movimentação do usuário e sua localização no plano durante a
realização do *survey*, bem como viabilizar a interpretação das medições
coletadas. Cada medição é registrada com a indicação (em uma interface
gráfica) de qual ponto do ambiente ela foi realizada, conforme ilustra a
Figura \ref{pontosSurvey}.

![Pontos das medições efetuadas em um *survey*](imagens/pontosSurvey.png){#pontosSurvey width="6.302329396325459in"
height="3.5416666666666665in"}

Fonte: o Autor


### Exibição gráfica dos dados

Por fim, o resultado final de todas as medições realizadas é apresentado
através de uma visualização gráfica. Devidamente calculada a
interpolação entre as medidas coletadas pelo iwlist e filtradas pelos
*scripts bash* desenvolvidos, somado ao uso de um mapa de calor provido
pelo GNUPLOT, o resultado (separados por camadas) é exibido na interface
gráfica da aplicação (GUI), conforme ilustra a Figura \ref{sobreposicaoPontos}.

![Sobreposição dos pontos de medições ao *heatmap*](imagens/sobreposicaoPontos.png){#sobreposicaoPontos width="6.302329396325459in"
height="3.5416666666666665in"}

Fonte: o Autor

Na Figura \ref{sobreposicaoPontos} é possível notar as sobreposições de camadas, onde: na
camada mais inferior é carregada uma planta-baixa do local de *survey*;
a segunda camada consiste no *heatmap* gerado e a terceira e última
camada fica encarregada de exibir os pontos das coletas. De posse de tal
resultado, é possível analisar a cobertura e localização dos APs Wi-Fi.
Por exemplo, pode-se observar na escala de cores a perda de intensidade
(com o aumento da distância) e a atenuação do sinal (pelos obstáculos),
no percurso desde o AP Wi-Fi até determinada medição efetuada pelo
usuário (ALMERS et al., 2007; LENTZ, 2003; SANDEEP, 2008).

## Verificação 

### Ajustes

Durante e após a implementação do mecanismo de coleta de medições e sua
interface gráfica, os resultados obtidos foram utilizados para ajustar o
software desenvolvido, num processo de melhoria contínua visando que a
solução fosse apresentada de maneira mais intuitiva.

A princípio houve a tentativa de gerar o mapa de calor utilizando a
biblioteca java AWT, mas devido à demora da mesma e baixa resolução da
imagem gerada, considerando a facilidade e qualidade que o GNUPLOT
proporcionou este foi adotado como o método para gerar o *heatmap*.
Inicialmente, os heatmaps eram gerados com as cores *default* do GNUPLOT
(gradiente roxo para amarelo), conforme ilustra a Figura \ref{roxoAmarelo}.

![*Heatmap* com gradiente de cores “roxo ⇒ amarelo”](imagens/roxoAmarelo.png){#roxoAmarelo width="3.9791666666666665in"
height="2.441519028871391in"}

Fonte: o Autor

Após comparação com a escala de cores utilizada pelos trabalhos
relacionados, visando prover uma melhor interpretação foi utilizado um
novo esquema de cores (gradiente azul para vermelho). Tal gradiente
remete a “quente e frio” que, melhor simbolizando a intensidade de sinal
com o aumento da distância (perto ou longe) da fonte de radiação de
sinal. A Figura \ref{azulVermelho} ilustra a escala de cores “frias” e “quentes”
utilizada.

![*Heatmap* com gradiente de cores “azul ⇒ vermelho”](imagens/azulVermelho.png){#azulVermelho width="3.8708584864391953in" height="2.21875in"}

Fonte: o Autor

Outros tratamentos necessários foram um corte e uma inversão na imagem
gerada pelo GNUPLOT. O corte foi necessário, pois os valores e os eixos
que apareciam no plot se não encaixavam bem na sobreposição da
planta-baixa exibida na GUI. A inversão de eixo foi devido ao fato dos
pontos serem coletados em uma tela em Java, onde os valores de X crescem
da esquerda para direita e de Y de cima para baixo (origem no canto
superior esquerdo), enquanto que o GNUPLOT pressupõe que o eixo Y cresce
de baixo para cima (origem no canto inferior esquerdo).

![Painéis da interface gráfica (GUI) do software produzido](imagens/paineis.png){#paineis width="6.302329396325459in"
height="3.5416666666666665in"}

Fonte: o Autor

Durante o desenvolvimento da interface surgiu a necessidade de criar uma
área específica para a exibição gráfica dos mapas e condução do *survey*
(área em azul). Porém, no início, quando os pontos eram coletados só
havia um evento que capturava o clique do mouse e este evento pegava a
posição em qualquer área da janela principal (soma das áreas azul,
laranja, verde e menu superior). Isso gerava o problema de pontos fora
da medição atrapalharem a interpretação da imagem gerada pelo GNUPLOT,
que deixava fora de escala o heatmap. Esse problema logo foi resolvido,
pois na biblioteca Java Swing basta definir de qual componente da GUI o
evento do mouse deverá ser capturado (no caso o painel em azul).

Com a normalização do sistema de coordenadas, teve início o
desenvolvimento de um método para carregar a representação do ambiente
no espaço disponível na GUI sem que a imagem da planta-baixa fosse
cortada. Para isso ela é carregada e redimensionada em como uma nova
imagem, mantendo a integridade do arquivo original e proporcionando a
escala necessária para que a medição conduzida pela GUI corresponda ao
desejado.

Durante o processo de sobreposição de imagens, tivemos que fixar a
resolução máxima para o tamanho do painel com a planta-baixa para o
mesmo valor limite que o GNUPLOT permite para os eixos X e Y de um
*heatmap*, sendo esses valores 1000 por 1000 (x e y menores ou iguais a
1000). Tal ajuste foi necessário para manter a escala da planta com a
escala do heatmap, de maneira que o painel com a representação do
ambiente teve sua resolução fixada em 1000 x 600, de maneira que toda
nova imagem carregada será redimensionada para este tamanho.

![Sobreposição das imagens em camadas](imagens/sobreposicaoCamadas.png){#sobreposicaoCamadas width="6.126189851268592in"
height="3.662632327209099in"}

Fonte: o Autor

Já com tudo devidamente ajustado em relação aos pontos das mediçẽos e
exibição gráfica do *heatmap*, surgiu um novo problema: ao atualizar o
*heatmap* os pontos da medição não ficavam em exibição na interface, o
que poderia deixar o usuário sem referência e “espacialmente perdido”
durante a condução do *survey*. Então, o código foi adaptado para
utilizar Java *Threads*, paralelizando cada etapa do processo: uma
responsável por coletar os dados, outra por gerar o heatmap e outra para
desenhar os pontos usando a biblioteca Graphics2D do AWT.

Fazendo alguns testes preliminares com iwlist percebeu-se que existe uma
demora maior para o retorno de sua saída de acordo com quantidade de APs
em determinado ambiente. Tecnicamente seria possível instruir o iwlist a
filtrar sua varredura pelo nome da rede Wi-Fi (ESSID) alvo, informada
diretamente nos parâmetros do comando iwlist. Entretanto, de acordo com
o manual do iwlist alguns *drivers* podem ignorar esta opção, o que
ocorreu com o hardware utilizado nos testes e poderia ocorrer com outros
usuários também.

A atualização da representação gráfica do *wireless survey* deve ser
realizada de maneira coordenada, devendo haver alguns segundos de espera
pois gasta-se certo tempo para coletar a nova medição e então gerar o
mapa de calor atualizado, ação que seria disparada toda vez que ocorrer
o evento de clique do mouse no painel da GUI. Para não passar ao usuário
uma falsa impressão de que o software havia “travado” ou era demasiado
lento, as atualizações gráficas são feitas por *threads* separadas,
evitando que o usuário tenha que (desnecessariamente) esperar muito
tempo parado no mesmo lugar até que a nova imagem do heatmap tenha sido
atualizada. A cada clique, tão breve quanto a coleta da medição tenha
sido realizada, é desenhado o novo ponto da coleta sobre a planta do
ambiente, com a semântica de que com o aparecimento de um novo ponto o
usuário já pode mover-se para realizar nova medição. Momentos após, o
gráfico do *heatmap* será atualizado pela thread que continuou seu
trabalho em segundo plano, disparada após a coleta do iwlist ter sido
concluída.

### Teste

![Fluxograma das etapas para realização do *survey*](imagens/fluxograma.png){#fluxograma width="6.302329396325459in"
height="3.0555555555555554in"}

Fonte: o Autor

Para validação da aplicação, um teste de grande escala foi realizado
terceiro pavimento do no bloco C, maior edifício do IFMG campus
Formiga. As figuras \ref{trajeto}, \ref{heatmapColeta} e \ref{coletaTrajeto} ilustram a execução dos passos do
fluxograma contido na Figura \ref{fluxograma}.

![Representação do trajeto da coleta de medições](imagens/trajeto.png){#trajeto width="4.854166666666667in"
height="2.847769028871391in"}

Fonte: o Autor

![*Heatmap* proveniente da coleta de medições](imagens/heatmapColeta.png){#heatmapColeta width="4.48330927384077in"
height="1.8781430446194225in"}

Fonte: o Autor

![Resultado combinado da coleta de medições](imagens/coletaTrajeto.png){#coletaTrajeto width="6.302329396325459in"
height="3.5416666666666665in"}

Fonte: o Autor

### Validação

Com a realização do teste bem sucedido, restava conduzir uma verificação
da validade dos dados coletados e sua representação visual. Para tal,
foi utilizado um simulador de propagação de sinais[^2] Wi-Fi
desenvolvido por outro aluno do curso de Ciência da Computação, Samuel
Terra Vieira, também como trabalho de conclusão de curso (VIEIRA, 2017).

[^2]: Disponivel em: \url{https://github.com/samuelterra22/tcc}

A Figura \ref{simulacao} apresenta a simulação de propagação dos sinais de Wi-Fi de
um AP posicionado no canto esquerdo do terceiro pavimento do bloco C do
campus Formiga. Note como o sinal Wi-Fi enfraquece com o aumento da
distância entre o AP e os pontos da simulação. A escala de cores do
simulador vai de verde a vermelho e onde há ausência de cor o sinal
recebido estaria abaixo no nível de potência mínimo (tipicamente abaixo
de -90 dBm) para realização de uma conexão com o AP Wi-Fi.

![Simulação da intensidade de sinal Wi-Fi](imagens/simulacao.png){#simulacao width="6.302329396325459in"
height="2.4027777777777777in"}

Fonte: (VIEIRA, 2017)

Já a Figura \ref{medicao} apresenta os resultados do *Wireless Site Survey*
realizado com o software desenvolvido neste trabalho. Comparado aos
resultados da simulação da Figura \ref{simulacao} com a medição real da Figura \ref{medicao},
observa-se um casamento entre o esperado e o observado, uma vez que o
sinal no corredor (no centro, horizontalmente) permanece com um nível de
potência razoável, ao passo que as salas nos cantos direito superior e
inferior apresentaram em ambos os casos um nível de potência de sinal
demasiado baixo (roxo, na escala de cor deste trabalho e preto naquele).
Observe também a fileira de carteiras no canto direito da Figura \ref{medicao}
que, ao contrário do restante da sala, ainda apresenta um sinal com
potência abaixo do mínimo (azul claro). Na simulação da Figura \ref{simulcao}, tal
comportamento era esperado pois receberia o facho de sinais provenientes
do corredor.

![Medição da intensidade de sinal Wi-Fi](imagens/medicao.jpg){#medicao width="6.302329396325459in"
height="2.4027777777777777in"}

Fonte: o Autor

## Materiais

Para a condução dos experimentos, foi utilizado um Notebook Samsung,
modelo[^3] ATIV Book 6 670Z5E-XD1BR, com a seguinte configuração:

-   Processador - Intel(R) Core(™) i5-3230M CPU 2.60GHz

-   Memória RAM - 8GB DDR3 single channel

-   Interface de rede sem fio - **Centrino Advanced-N 6235**

    -   Streams TX/RX 2x2

    -   Bandas **2.4 GHz/ 5GHz**

    -   Velocidade máxima 300 Mbps

    -   Padrões suportados **Wi-Fi 802.11 a/b/g/n**

    -   Conformidade PCI, CISP, FIPS, FISMA

    -   Bluetooth integrado Sim

Para a implementação do software desenvolvido, foram utilizados os
seguintes softwares:

-   Sistema Operacional - Linux Mint 18.1 Cinnamon 64-bit

-   Pacote *wireless-tools*: versão 30\~pre9-8ubuntu1

-   Pacote *GNUPLOT*: versão 4.6.6-3

-   Java JDK: versão 1.8.0\_151 - Java HotSpot(TM) 64-Bit Server VM
    25.151-b12

-   IDE para desenvolvimento da GUI: NetBeans 8.2

[^3]: Disponivel em: \url{http://www.samsung.com/br/support/model/NP670Z5E-XD1BR}

# RESULTADOS E ANÁLISE

De posse do software desenvolvido, testado e validado, foram realizados
experimentos em uma instituição de ensino e em uma residência. Abaixo
são apresentados e discutidos os resultados obtidos.

## Cenário 1 - pavimento de um edifício

![Intensidade de sinal da rede wifi-alunos (bloco c, 3º pavimento)](imagens/blocoC0.png){#blocoC0 width="6.302329396325459in"
height="3.5416666666666665in"}

Fonte: o Autor

A Figura \ref{blocoC0} apresenta os resultados obtidos para o *wireless site
survey* realizado no terceiro pavimento do bloco C do IFMG campus
Formiga. Vale ressaltar que, por questões de privacidade, não foram
realizadas medições de sinal dentro dos banheiros masculino e feminino
(posição superior central da imagem), entretanto, pela interpolação
gerada pelo *heatmap* gerado pelo GNUPLOT, pode-se prever o nível de
potência do sinal que seria ali recebido.

\clearpage

![Detalhe da intensidade de sinal em salas periféricas](imagens/blocoC1.png){#blocoC1 width=80%}

Fonte: o Autor

Ao observarmos o detalhe dos resultados apresentado na Figura BBB, é
possível notar que existe uma boa intensidade de sinal sendo propagada
na sala da direita, enquanto na da esquerda nem tanto. Analisando o
*heatmap*, tal fato poderia ser explicado pelo ângulo de incidência do
sinal propagado pelo corredor horizontal, que termina em uma parede e
possui um desvio de 90º para continuação do corredor. Este detalhe
arquitetônico faz com que a sala da esquerda esteja na **região de
sombra da difração** do sinal Wi-Fi incidente no término do corredor. Já
a sala da direita, beneficia-se da difração ocorrida na quina da parede,
no término do corredor, ressaltada como um retângulo preto na Figura
\ref{blocoC1}.

Vale lembrar que, na escala de cores, a cor azul não representa ausência
completa de sinal, pois o local marcado com um ponto preto representa um
AP que mesmo estando fora da sala é capaz de irradiar seu sinal para
dentro dela. Isso pode ocorrer pelo fato de as reflexões, difrações e
dispersões da propagação do Wi-Fi serem favoráveis àquela posição.
Também é válido ressaltar que a parede entre o ponto de acesso e a sala
da direita possui um seguimento de janelas no topo bem em frente ao
roteador, melhorando assim a irradiação do sinal para aquele local.

\clearpage

![Detalhe da absorção do sinal por múltiplas paredes](imagens/blocoC2.png){#blocoC2 width=80%}

Fonte: o Autor

Outro ponto que sofre bastante atenuação do sinal são as salas menores
no canto inferior direito do ambiente avaliado. Observe na Figura \ref{blocoC2}
que o sinal proveniente do AP (representado por um círculo preto)
necessita atravessar de duas a três paredes para incidir dentro das
salas no detalhe. Na imagem, as barras verticais representam paredes que
contém grande concentração de cabos de energia (duto de passagem entre
os pavimentos do edifício).

\clearpage

![Detalhe do sinal próximo ao elevador](imagens/blocoC3.png){#blocoC3 width=80%}

Fonte: o Autor

Na região central superior do ambiente analisado encontra-se um
elevador, bem ao lado do AP, o que pode causar grande interferência na
propagação do sinal em virtude das chapas de metais que compõe as portas
do elevador. Na Figura \ref{blocoC3}, o tal elevador é representado por um
retângulo preto e a posição do AP consiste no círculo vermelho. Observe
como há uma atenuação do sinal no corredor à direita, pelo fato das
portas metálicas do elevador não permitirem a passagem do sinal através
delas, por consistir em um dielétrico para as microondas.

\clearpage

![Detalhe de APs bem e mal posicionados](imagens/blocoC4.png){#blocoC4 width=80%}

Fonte: o Autor

A Figura \ref{blocoC4} apresenta dois APs localizados no mesmo ambiente avaliado,
porém posicionados de maneira diferente e em locais diferentes. Na
Figura \ref{blocoC4} (a), o AP foi posicionado em uma parede na qual há diversas
janelas de vidro, utilizadas para iluminação e circulação de ar no
corredor. Observe na Figura \ref{blocoC4} (a) que a sala adjacente ao AP recebe
ótima cobertura e intensidade de sinal Wi-Fi.

Agora, compare com a Figura \ref{blocoC4} (b), na qual o AP foi posicionado em uma
coluna de concreto para sustentação do bloco C, dificultando assim a
propagação do sinal para estas salas. Considerando a diferença na
densidade dos materiais da parede e da coluna de concreto, e o fato
desta última possuir um gradil de ferragens em sua construção, as
medições coletadas no interior da sala adjacente ao AP são consistentes
com os modelos de propagação de ondas eletromagnéticas, uma vez
considerada as diferentes condutividades, permissividades e
permeabilidades dos materiais (RAPPAPORT, 2009).

## Cenário 2 - uma residência

Analisando de forma geral a propagação do sinal na residência avaliada,
pela Figura \ref{casa0} é possível notar a baixa intensidade do sinal Wi-Fi nos
pontos “mais frios” (cor roxa), mais à esquerda do ambiente avaliado,
bem como a alta intensidade dos sinais Wi-Fi nos pontos mais “quentes”
(cor vermelha), mais à direita do ambiente avaliado.

\clearpage

![Intensidade de sinal em uma residência](imagens/casa0.png){#casa0 width="5.25in" height="2.9460050306211722in"}

Fonte: o Autor

![Detalhe com a posição do AP](imagens/casa1.png){#casa1 width=80%}

Fonte: o Autor

Pela Figura \ref{casa1}, além de observar o posicionamento do AP (representado
como um círculo preto), observe os pontos com sinal mais fraco (roxo) no
cômodo central. Além de estar mais afastado do AP que o cômodo no canto
direito, os pontos roxos ficam próximos a eletrodomésticos grandes e com
robusta estrutura metálica, no caso uma geladeira e um freezer. Assim,
nos pontos com zonas de sombra (roxo) o cômodo central sofre perdas
maiores do que o cômodo no canto superior esquerdo, que encontra-se mais
distante do AP mas possui alguns locais com maior intensidade de sinal
(azul claro). Em parte, tal fato pode também ser explicado pois, além de
receber as reflexões de sinal provenientes dos eletrodomésticos citados,
existe uma janela de aproximadamente 2 m x 1,5 m aberta no cômodo
superior esquerdo com visão direta ao ponto de acesso.

![Detalhe do comodo com a posição do AP](imagens/casa2.png){#casa2 width=80%}

Fonte: o Autor

Averiguando os resultados obtidos com as medições realizadas no cômodo
em que se encontra o AP da residência, pela Figura \ref{casa2} é importante (e
curioso) observar que, próximos à área onde o sinal está mais fraco
(azul claro), havia duas pessoas entre o AP e o notebook utilizado na
coleta das medições. Já na região próxima à janela da direita, havia uma
pessoa sentada em uma cadeira. Isso mostra que não só paredes, móveis e
eletrodomésticos, mas também o corpo humano interfere na propagação do
sinal Wi-Fi, pois a composição orgânica do corpo (com grande
concentração de água), absorve boa parte do sinal por ele transmitido.

# CONSIDERAÇÕES FINAIS

Durante o desenvolvimento do software de avaliação de sinal WiFi sem
limitações na coleta dos dados e FOSS para o SO linux, conhecimentos de
diversas áreas foram adquiridos, áreas como, operações com scripts bash
no SO linux, um pouco de desenvolvimento de interfaces java, interação
da linguagem java com outros programas do SO, conhecimento e um certo
nível de entendimento a respeito de comunicação sem fio em redes para
uma melhor interpretação dos resultados da ferramenta desenvolvida,
entre outras áreas. Ao analisar os resultados obtidos, foi possível
aferir que o software desenvolvido não deixa a desejar quando se trata
do objetivo principal de um *site survey.* Algumas funcionalidades ainda
podem ser adicionadas, outras melhor ajustadas, mas o cerne do programa
está de acordo com o previsto.

O software desenvolvido foi validado através da comparação das medições
realizadas com um simulador da propagação de ondas de radiofrequência,
bem como foi testado em edifício da instituição de ensino e em uma
residência. O programa compilado e seu código-fonte podem ser obtidos
gratuitamente através do repositório GitHub[^4], sob o nome *Wireless
Site Survey*. A aplicação desenvolvida demonstrou ter grande potencial,
tanto pela precisão dos resultados obtidos e impactos de sua análise
quanto pela possibilidade da comunidade de software livre poder
contribuir com ajustes e novas melhorias, uma vez que as alternativas
são softwares proprietários que custam de centenas a milhares de
dólares.

Como trabalhos futuros, sugere-se a adição de funcionalidades na
interface gráfica da aplicação, a possibilidade da criação e exportação
de projetos, viabilizar uma forma de identificar pela própria aplicação
quais redes (SSID) e APs (MAC) estão visíveis no local da coleta.

[^4]: Disponivel em: \url{https://github.com/vinicius023/Wireless-Site-Survey}