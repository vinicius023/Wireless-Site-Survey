MEC-SETEC

INSTITUTO FEDERAL MINAS GERAIS - *Campus* Formiga

Curso de Ciência da Computação

**SOFTWARE LIVRE PARA *WIRELESS SITE SURVEY***

Vinícius de Laet Duarte Batista

Orientador: Prof. M.e Everthon Valadão

FORMIGA- MG, 2017

VINICIUS DE LAET DUARTE BATISTA

**SOFTWARE LIVRE PARA *WIRELESS SITE SURVEY***

> Monografia do trabalho de conclusão de curso apresentado ao Instituto
> Federal Minas Gerais - *Campus* Formiga, como requisito parcial para a
> obtenção do título de Bacharel em Ciência da Computação.
>
> Orientador: Prof. Me. Everthon Valadão.

Agradecimentos
==============

Agradeço primeiramente a Deus e aos meus pais que me deram forças para
continuar nessa longa jornada.

Ao meu orientador e a meus amigos por acreditarem em mim, por me
incentivarem mesmo quando eu estava mais desanimado.

A todos os professores que me ajudaram de alguma forma durante o
desenvolvimento deste trabalho.

E sou grato à toda equipe de professores do IFMG que fizeram parte da
minha formação tanto intelectual como de caráter.

Hoje sou o que sou graças a todos que me apoiaram a chegar até aqui.

 
=

Resumo
======

O site *survey* (ou *wireless survey*) é muito importante no projeto de
uma rede sem fio. Com ele é possível determinar e antecipar possíveis
pontos de falha na cobertura de uma rede Wi-Fi, diagnosticar áreas de
sombra, de interferências de sinal e determinar a melhor localização dos
pontos de acesso (APs). Este trabalho de conclusão de curso tem por
objetivo desenvolver um software livre de código-fonte aberto (FOSS)
para conduzir um *Wireless Site Survey*, ou seja, uma avaliação dos
sinais Wi-Fi providos por um ou mais AP *wireless* (pontos de acesso sem
fio) em determinado local, através de medições das características dos
sinais e sua posição no plano, fornecendo uma representação gráfica dos
resultados sobreposta ao plano do local. Os principais passos que foram
tomados para a realização integral das especificações propostas deste
TCC: preparação e projeto, coleta das medições, visualização dos dados,
implementação, interpretação dos dados da coleta, exibição gráfica dos
dados, testes e ajustes, experimentos e validação, materiais. O programa
compilado e seu código-fonte podem ser obtidos gratuitamente no
repositório
[[https://github.com/vinicius023/Wireless-Site-Survey]{.underline}](https://github.com/vinicius023/Wireless-Site-Survey).

**Palavras-chave**: Wi-Fi, *wireless survey*, avaliação de rede sem fio,
FOSS.

Abstract
========

The survey (or wireless survey) site is very important in designing a
wireless network. It is possible to determine and anticipate possible
points of failure in the coverage of a Wi-Fi network, diagnose areas of
shadow, signal interference and determine the best location of access
points (APs). This course completion work aims to develop an Open Source
Free Software (FOSS) to conduct a Wireless Site Survey, in an evaluation
of the Wi-Fi signals provided by one or more wireless APs ) in a given
location, by measuring the characteristics of the signals and their
position in the plane, providing a graphical representation of the
results superimposed on the site plan. The following are the main steps
taken to fully realize the proposed specifications of this work:
preparation and design, collection of measurements, data visualization,
implementation, interpretation of collection data, graphical data
display, tests and adjustments, experiments and validation, materials.
The compiled program and its source code can be obtained free from:
[[https://github.com/vinicius023/Wireless-Site-Survey]{.underline}](https://github.com/vinicius023/Wireless-Site-Survey)
repository.

**Keywords:** Wi-Fi, *wireless survey*, wireless network assessment,
FOSS.

 
=

Lista de figuras
================

⇒ Gerada automaticamente pelo LaTeX, LibreOffice ou Word (caso coloque a
legenda da tabela da maneira apropriada para o software).

 
=

Lista de tabelas
================

⇒ Gerada automaticamente pelo LaTeX, LibreOffice ou Word (caso coloque a
legenda da figura da maneira apropriada para o software).

 
=

Lista de abreviaturas, acrônimos e siglas 
==========================================

FOSS *Free Open Source Software*

RCPI *Received Channel Power Indicator*

Wi-Fi Vem do termo *Wireless Fidelity*, mas representa uma rede local
sem fio

GUI Graphical User Interface

BASH Acrônimo para \"*Bourne-Again Shell*\", é um interpretador de
comandos

WLAN *Wireless Local Area Network* (rede de área local sem fio)

IEEE Instituto de Engenheiros Eletricistas e Eletrônicos

AP Access Point

PA Ponto de Acesso

RF Radiofrequência

GHz Gigahertz

SO Sistema Operacional

ESSID *Extended Service Set Identifier* (identificador da rede)

TKIP *Temporal Key Integrity Protocol*

AES *Advanced Encryption Standard*

MIMO *Multiple-input and multiple-output*

RSSI *Received signal strength indicator*

RSNI *Received signal to noise indicator*

SNR *Signal-to-noise ratio*

AWT *Abstract Window ToolKit*

TX *Transmitter*

RX *Receiver*

RAM *Random Access Memory*

CISP *Cardholder Information Security Program*

PCI *Payment Card Industry Data Security Standard*

FISMA *Federal Information Security Management Act*

FISP *Federal Information Processing Standards*

dbm *Decibel miliwatt*

Mbps Megabit por segundo

W *Watt*

WPA *Wi-Fi Protected Access*

WEP *Wired Equivalent Privacy*

CPU *Central Processing Unit*

PDCA PLAN - DO - CHECK - ACT ou *Adjust*, planejamento, desenvolvimento,
validação e ajuste

GNU GNU\'s Not Unix, é um sistema operacional tipo Unix cujo objetivo
desde sua concepção é oferecer um sistema operacional completo e
totalmente composto por software livre.

MAC *Media Access Control*, é um endereço físico associado à interface
de comunicação, que conecta um dispositivo à rede.

OSI *Open System Interconnection*, criado com objetivo de ser um padrão,
para protocolos de comunicação entre os mais diversos sistemas em uma
rede local (Ethernet), garantindo a comunicação entre dois sistemas
computacionais (*end-to-end*).

OFDM *Orthogonal frequency-division multiplexing*, é um método de
codificação digital que utiliza múltiplas subportadoras.

GNUPLOT Programa de linha de comando que plota os gráficos de funções
matemáticas em duas ou três dimensões, e outros conjuntos de dados.

 
=

Sumário
=======

 
=

INTRODUÇÃO
==========

*Wireless Survey* é uma forma de inspeção de rede sem fio através da
análise da intensidade de sinal Wi-Fi de determinada área ou WLAN
específica. A medição é feita pelo canal da banda de frequência, de
acordo com o padrão Wi-Fi considerado (2.4 GHz no caso do IEEE 802.11
b/g/n ou 5 GHz no 802.11 a/ac).

Com os dados coletados por uma ferramenta de *wireless survey* é
possível analisar um melhor posicionamento para os pontos de acesso
(APs) à rede sem fio levando em conta os locais de maior interferência
de sinal observados. Também é possível verificar se é necessário o
acréscimo do número de APs. O sinal Wi-Fi pode sofrer interferência de
qualquer produto capaz de emitir sinais de RF na mesma faixa de
frequência do ponto de acesso que o emite. Geralmente isso ocorre quando
algum equipamento também está em uma frequência de 2.4 GHz (ou 5.8 GHz,
conforme o caso).

A aplicação deste método de análise é cabível quando é notado que a rede
Wi-Fi em uso apresenta baixa qualidade no canal e/ou queda de desempenho
da rede, sem que esta seja causada pelo uso massivo de usuários da rede
em questão. O *wireless survey* também é muito utilizado no planejamento
de uma nova rede Wi-Fi, por exemplo, evitando-se locais com
preexistência de APs trabalhando na mesma frequência.

Nas seções a seguir serão apresentados os objetivos e justificativas
deste projeto, bem como a metodologia para o desenvolvimento de uma
aplicação *wireless survey* gratuita e de código fonte aberto, com
suporte ao sistema operacional GNU/Linux.

Justificativa
-------------

O site *survey* (ou *wireless survey*) é muito importante no projeto de
uma rede sem fio. Com ele é possível determinar e antecipar possíveis
pontos de falha na cobertura de uma rede Wi-Fi, diagnosticar áreas de
sombra, de interferências de sinal e determinar a melhor localização dos
pontos de acesso (APs), assim como o melhor modelo e potência mais
adequados. Além disso serve como uma certificação para o ambiente onde a
rede *wireless* será instalada.

O intuito da realização deste trabalho é disponibilizar para a
comunidade acadêmica e externa uma ferramenta capaz de realizar medições
com precisão e sem limitações na coleta da intensidade de sinal Wi-Fi,
para ser usado em suas instituições/empresas, mostrando de forma simples
e intuitiva os possíveis locais com deficiência de cobertura de sinal
Wi-Fi.

De posse do relatório de inspeção gerado pela ferramenta, o responsável
pela rede poderá promover mudanças que visem a sanar tais deficiências.
Porém esta aplicação não se limita ao uso em apenas empresas ou
instituições, ela poderá também ser utilizada por usuário residencial
que tenha interesse em encontrar uma posição mais eficiente para seu (s)
ponto (s) de acesso (APs).

Como as tecnologias Wi-Fi (802.11) têm se popularizado e estão cada vez
mais integradas à comunidade em geral, uma ferramenta para inspeção de
redes sem fio será bem vinda.

Até o momento da pesquisa não foi encontrado uma ferramenta com suporte
para os Sistemas Operacionais GNU/Linux, apenas recursos de bash já
presentes no SO, como por exemplo *iwlist*.

Objetivos 
----------

O objetivo geral deste trabalho de conclusão de curso é desenvolver um
software livre de código-fonte aberto (FOSS) para conduzir um *Wireless
Site Survey*, ou seja, uma avaliação dos sinais Wi-Fi providos por um ou
mais AP *wireless* (pontos de acesso) em determinado local, através de
medições das características dos sinais e sua posição no plano,
fornecendo uma representação gráfica dos resultados sobreposta ao plano
do local.

### Objetivos Específicos

-   Criar um software livre para medição de características dos sinais
    > Wi-Fi (ex.: intensidade do sinal, qualidade do sinal, frequência e
    > canal, ESSID da rede, endereço MAC do AP, padrões Wi-Fi suportados
    > e taxas de bits);

-   Fornecer mecanismo prático para marcação da posição medida no plano
    > do edifício (ex.: planta-baixa, sketch), sendo este fornecido como
    > entrada ao software;

-   Prover uma visualização gráfica das características dos sinais
    > Wi-Fi, através de mapa de calor (*heatmap*) ou similar, no
    > relatório de saída e/ou durante as medições;

-   Disponibilizar o software gratuitamente, livre e com código-fonte
    > aberto (FOSS), com suporte inicial a sistemas operacionais
    > GNU/Linux.

1.  FUNDAMENTAÇÃO TEÓRICA
    =====================

    1.  Padrões Wi-Fi (IEEE 802.11)
        ---------------------------

Os padrões de rede sem fio local (WLAN) IEEE 802.11, também conhecidas
como redes Wi-Fi ou *wireless*, foram uma das grandes novidades
tecnológicas na história recente da comunicação de dados. Uma WLAN
possui como principal característica transmitir sinal sem fio através de
ondas de radiofrequência,Atuando nas camadas de enlace e física do
modelo OSI, os padrões IEEE 802.11 utilizam uma série de padrões de
transmissão e codificação para comunicações sem fio, dos quais aqueles
referentes ao Wi-Fi. Atualmente, é o padrão de fato em conectividade sem
fio para redes locais (IEEE 802.11-2016).

**IEEE 802.11b**: alcança uma taxa de transmissão de 11 Mbps padronizada
pelo IEEE e uma velocidade de 22 Mbps, oferecida por alguns fabricantes.
Opera na frequência de 2.4GHz. Inicialmente suporta 32 utilizadores por
ponto de acesso.

**IEEE 802.11g**: baseado na compatibilidade com os dispositivos
802.11b, oferece uma velocidade de até 54 Mbps. Funciona dentro da
frequência de 2,4GHz. Usa autenticação
[WEP](https://pt.wikipedia.org/wiki/Wep) estática já aceitando outros
tipos de autenticação como [WPA](https://pt.wikipedia.org/wiki/WPA)
(*Wireless Protect Access*) com
[criptografia](https://pt.wikipedia.org/wiki/Criptografia) (método de
criptografia [TKIP](https://pt.wikipedia.org/wiki/TKIP) e
[AES](https://pt.wikipedia.org/wiki/Advanced_Encryption_Standard)).

**IEEE 802.11n**: as principais especificações técnicas deste padrão
incluem: - Taxas de transferências disponíveis: de 65 Mbps a 450 Mbps. -
Método de transmissão:
[**MIMO**](https://pt.wikipedia.org/wiki/MIMO)-OFDM - Faixa de
frequência: 2,4GHz e/ou 5GHz.

O 802.11n (também conhecido como \"Wireless N\") foi projetado para
melhorar o 802.11g na quantidade de largura de banda suportada pela
utilização de múltiplos sinais e antenas sem fio (chamado tecnologia
MIMO) em vez de um.

Os grupos de padrões da indústria ratificaram o 802.11n em 2009 com
especificações que fornecem até 300 Mbps de largura de banda de rede. O
802.11n também oferece um alcance um pouco melhor em relação aos padrões
anteriores do Wi-Fi devido ao aumento da intensidade do sinal, e é
compatível com 802.11b/g.

-   Prós do 802.11n - velocidade máxima mais rápida e melhor faixa de
    > sinal; mais resistente à interferência de sinal de fontes
    > externas.

-   Contras do 802.11n - Standard ainda não foi finalizado; custa mais
    > de 802.11g; o uso de múltiplos sinais pode interferir grandemente
    > nas redes baseadas em 802.11b / g nas proximidades.

**IEEE 802.11a**: Embora ajude a melhorar o desempenho da rede e reduzir
a interferência, a faixa de sinal de 802.11a foi limitada pelo uso de
freqüências de 5 GHz, podendo alcançar velocidades de 54 Mbps de acordo
com os padrões IEEE 802.11 e 108 Mbps por fabricantes que não seguem
este padrão. Um transmissor de Ponto de Acesso (PA) com este padrão pode
cobrir menos de um quarto da área de uma unidade equivalente de
802.11b/g. As paredes de tijolos e outras obstruções afetam as redes sem
fio 802.11a em maior grau do que as redes 802.11 b/g comparáveis.

Chega a alcançar velocidades de 54 Mbps dentro dos padrões da IEEE e de
72 a 108 Mbps por fabricantes não padronizados. Esta rede inicialmente
suporta 64 utilizadores por PA.

**IEEE 802.11ac**: O padrão trabalha em uma faixa de frequência de 5 GHz
(menos interferência). IEEE 802.11ac opera com taxas nominais maiores
que utilizam velocidade de até 1 Gbps, padronizando em 1300 Mbps
trabalhando na faixa de 5 GHz.

O padrão Wi-Fi mais novo e em uso popular, o 802.11ac, utiliza
tecnologia sem fio de banda dupla (*dual band*), suportando conexões
simultâneas em bandas Wi-Fi de 2,4 GHz e 5 GHz. Ele oferece
compatibilidade com versões anteriores para 802.11b/g/n e banda larga de
até 1300 Mbps na frequência de 5 GHz e mais 450 Mbps em 2,4 GHz.

Para ser competitivo na indústria e apoiar aplicações cada vez mais
comuns, como o streaming de vídeo que exigem redes de alto desempenho, o
802.11ac foi projetado para funcionar de forma semelhante a Gigabit
Ethernet.

De fato, o 802.11ac oferece taxa de dados teórica de até 1 Gbps. Isso se
faz por uma combinação de aprimoramentos de sinalização sem fio, em
particular:

-   Canais que utilizam uma extensão maior (mais larga) de frequências
    > de sinal;

-   Maior número de rádios de múltiplas entradas e múltiplas saídas
    > (MIMO) e antenas para permitir mais transmissões simultâneas;

O 802.11ac opera na faixa de sinal de 5 GHz ao contrário da maioria das
gerações anteriores de Wi-Fi que utilizam canais de 2,4 GHz.

Os designers do 802.11ac fizeram essa escolha por dois motivos:

1.  Para evitar problemas de interferência sem fio comum a 2,4 GHz, já
    > que muitos outros tipos de dispositivos de consumo usam essas
    > mesmas freqüências (devido a decisões regulatórias do governo);

2.  Para implementar canais de sinalização mais amplos (como mencionado
    > acima) do que o espaço de 2,4 GHz permite confortavelmente.

Para manter a compatibilidade com versões anteriores de produtos Wi-Fi
mais antigos, os roteadores de rede sem fio 802.11ac também incluem
suporte de protocolo separado de 2,4 GHz em estilo 802.11n. Outra nova
característica do 802.11ac chamado *beamforming* foi projetada para
aumentar a confiabilidade das conexões Wi-Fi em áreas mais lotadas. A
tecnologia *beamforming* permite que os rádios Wi-Fi apontem seus sinais
na direção específica das antenas receptoras em vez de espalhar o sinal
em 180 ou 360 graus, como fazem os rádios tradicionais. O *beamforming*
é uma lista de recursos designada pelo padrão 802.11ac como opcional,
juntamente com canais de sinal duplo (160 MHz em vez de 80 MHz) e vários
outros itens.

Propagação e Atenuação de Sinais de Rádio
-----------------------------------------

As ondas de rádio (notadas RF para Radiofrequência) propagam-se em linha
reta em várias direções. A velocidade de propagação das ondas no vazio é
de 3 x 10\^8 m/s. Entretanto, o sinal não chega ao receptor com a mesma
potência transmitida. A propagação das ondas de rádio impõe perdas ao
sinal, existindo diversas causas para essa degradação. Dentre as
principais, podem ser citadas o desvanecimento (fading), a absorção, e o
ruído. O termo \"desvanecimento\" é utilizado para referir-se a qualquer
flutuação ou variação na intensidade de um sinal que ocorra no receptor
durante o período em que esse sinal é recebido.

Quando uma onda de rádio encontra um obstáculo, uma parte da sua energia
é absorvida e transformada em energia, uma parte continua a propagar-se
de maneira atenuada e uma parte pode eventualmente ser refletida. A
atenuação de um sinal é a redução de potência e de transmissão. O
enfraquecimento é medido em Bels (cujo símbolo é B) e equivale ao
logaritmo base 10 da potência à saída do suporte de transmissão (P2),
dividido pela potência à entrada (P1). Prefere-se geralmente utilizar o
decibel (cujo símbolo é dB) que corresponde a um décimo do valor Bels.
Sendo que Bel representa 10 decibéis a fórmula passa a ser :

R (dB) = (10) \* log (P2/P1)

Quando R é positivo, trata-se de amplificação, quando é negativo
trata-se de atenuação. No caso das transmissões sem fios, trata-se
geralmente de atenuação. A atenuação aumenta com o aumento da frequência
ou com a distância. Quando há colisão com um obstáculo, o valor da
atenuação depende muito do material que compõe o obstáculo. Geralmente,
os obstáculos metálicos provocam uma forte reflexão, enquanto a água
absorve o sinal.

Ademais, existem diversas fontes de ruído que afetam a recepção da onda
de rádio. O ruído pode ser originado na natureza (fontes naturais) ou
gerado pelo homem (fontes artificiais). No primeiro caso, enquadra-se o
ruído atmosférico, que é geralmente a maior causa de ruído na faixa de
alta freqüência, já no segundo caso, podem ser incluídos os ruídos
causados por ignição de motores de combustão, linhas de transmissão,
lâmpadas fluorescentes, máquinas em geral, cabos elétricos, dentre
outros.

Sistemas de *Wireless Site Survey*
----------------------------------

*Wireless Survey* ou *Site Survey* é uma técnica que pode ser utilizada
para medir e visualizar os níveis de intensidade do sinal de rede local
sem fio (WLAN) nos diversos ambientes de um edifício. Segundo Santos,

> *\"Wireless Site Survey, é um conjunto de métodos aplicados na
> avaliação técnica minuciosa do local de instalação de uma nova
> infraestrutura de rede wireless, na observação dos resultados obtidos
> das melhorias de uma infra-estrutura já utilizada ou, ainda, na
> detecção e resolução de possíveis problemas em um sistema ativo. Esses
> processos são efetuados, normalmente, durante o estudo de viabilidade
> do projeto, seja no levantamento da infra-estrutura necessária ou na
> instalação de uma nova rede estruturada, de equipamentos transmissores
> de radiofreqüência e redes wireless\".* (SANTOS, 2007)

Analisando o resultado de tal levantamento de informações de sinal
wireless, é possível verificar os ambientes que estão com boa cobertura
de sinal Wi-Fi, bem como aqueles que possuem níveis de sinal muito
fracos ou mesmo zonas de sombra (quando o sinal estiver abaixo da
sensibilidade do equipamento). Em seu trabalho sobre *Wireless Survey*,
Santos ainda afirma que:

> *\"Por meio da análise destes recursos é possível entender seu
> comportamento, descobrir áreas cobertas, checar interferências de
> radiofreqüência, indicar a disposição apropriada dos dispositivos
> wireless, determinar o melhor aproveitamento do local estudado quanto
> à cobertura e eficiência de sinais, bem como em relação à redução dos
> custos de investimento. A necessidade de se conduzir um Wireless Site
> Survey provém do abaixo exposto. Se um único AP não produzir cobertura
> suficiente para todos os dispositivos da rede, uma quantidade de
> células (área de cobertura do AP) pode ser adicionada para aumentar a
> abrangência da rede Wi-Fi.\".* (SANTOS, 2007)

Por meio da análise destes recursos é possível entender seu
comportamento, descobrir áreas cobertas, checar interferências de
radiofreqüência, indicar a disposição apropriada dos dispositivos
wireless, determinar o melhor aproveitamento do local estudado quanto à
cobertura e eficiência de sinais, bem como em relação à redução dos
custos de investimento. A necessidade de se conduzir um *Wireless Site
Survey* provém do abaixo exposto. Se um único AP não produzir cobertura
suficiente para todos os dispositivos da rede, uma quantidade de células
(área de cobertura do AP) pode ser adicionada para aumentar a
abrangência da rede Wi-Fi.

É recomendado que os APs de uma mesma rede tenham de 10 a 15% de
sobreposição para permitir que usuários remotos transitem sem perda de
conexão e com garantia de cobertura de sinal de RF. Os APs que fazem
fronteira uns com os outros devem ser colocados em diferentes canais de
transmissão para obtenção de melhor desempenho (RODRIGUES, 2007),
evitando interferências intercanais. Segundo Song (SONG, 2014), em uma
rede *wireless,* determinados problemas podem impedir que o sinal de RF
alcance todas as partes de uma área. Vários fatores poderão causar
interferências de sinal, tais como:

• Distorção multidirecional (mais conhecida como distorção de múltiplos
caminhos);

• Posição dos pontos de acesso (altura, centralização);

• Clientes 802.11b em uma célula 802.11g (mesma frequência mas padrões
diferentes);

• Reutilização do canal em APs demasiado próximos;

• Posição da(s) antena(s) no equipamento do cliente.

Entretanto, o problema encontrado com maior freqüência é a distorção
multidirecional, causada por reflexões de rádio. Quanto mais alto o
número de sinais de radiofreqüência na célula (região de cobertura do AP
*wireless*), mais alto será o nível de ruído dentro dela. Portanto, as
antenas de *access points* devem estar dispostas longe das superfícies
reflexivas à frequência em questão (ex.: objetos metálicos).

Categorias de *Site Survey*
---------------------------

Para solucionar os problemas acima expostos, é preciso localizar sua
ocorrência. O *Wireless Site Survey* facilita a definição das linhas de
radiofreqüência cobertas em um determinado espaço e possui recursos que
são utilizados para descobrir regiões em que a distorção de múltiplos
caminhos possa ocorrer -- áreas em que a interferência de RF é alta -- e
disponibilizar soluções para eliminar ou evitar esses obstáculos. Um
*site survey* que determina a área de cobertura de RF também ajuda a
escolher a quantidade de dispositivos. (WIRELESS, 2006). Pode-se
classificar o site survey em duas categorias:

***Indoor*:** consiste em realizar a inspeção de redes *wireless*,
buscando interferências, localização de *access points* e disposição
geográfica de APs. Esse tipo de inspeção fornece gráficos de intensidade
de sinais, mais práticos de serem analisados, visto que as pesquisas são
realizadas em espaços relativamente pequenos. As fontes de
interferências são menores nesses ambientes, o que facilita a escolha de
antenas e dispositivos transmissores e receptores (GEIER, 2002).

***Outdoor*:** consiste em realizar a inspeção de redes *wireless* em um
âmbito muito maior que o existente na modalidade *indoor*, por meio de
interferências mais complexas. Busca-se determinar a localização e
posição de *access points* e das antenas de transmissão de grande porte,
com base na disposição geográfica dos dispositivos e dos demais aspectos
de inspeção do *site survey*. Geralmente, é realizado em projetos ou
redes de grande porte que possuem diversas interligações com diferentes
redes localizadas em áreas distantes (GEIER, 2002).

Existem conceitos referentes às áreas de cobertura de redes wireless,
considerados como topologias básicas. Cada área coberta por sinais de RF
irradiados por um único dispositivo transmissor é chamada de Área de
Serviço Básica (Basic Service Area\[BSA\]), também conhecida como célula
(JARDIM, 2005).

Durante a avaliação do sinal Wi-Fi, informações que podem ser
consideradas importantes para análise dos resultados da medição
realizada são:

-   para qual(ais) ap(s) foi feita: serve para analisar se as posições
    > dos pontos transmissores de sinal estão de fato em uma localização
    > com uma boa intensidade ou qualidade de sinal;

-   qual rede está sendo analisada: ver se determinada rede tem uma boa
    > cobertura na área em avaliação;

-   quais frequências foram capturadas para cada ap: serve para
    > identificar possíveis interferências entre pontos de acesso que
    > estão transmitindo na mesma frequência;

-   em qual canal o ponto de acesso está operando: se um ap está
    > transmitindo à uma mesma frequência que outro se estiverem em
    > canais diferentes não causaram interferência entre si;

    1.  Trabalhos relacionados
        ----------------------

+-----------+-----------+-----------+-----------+-----------+-----------+
| Produto   | Sistema   | Licença   | Capacidad | Suporte a | Preço     |
|           | Operacion |           | e         | adaptador | (Dólar    |
|           | al        |           | Planejame | es        | \$)       |
|           | (SO)      |           | nto       | externos  |           |
|           |           |           | e Análise |           |           |
+===========+===========+===========+===========+===========+===========+
| AirMagnet | Windows   | Proprieta | Não       | Sim       | 3,447     |
| Survey    |           | rio       |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+
| Ekahau    | Windows/  | Proprieta | Sim       | Sim       | 2,295     |
| Site      |           | rio       |           |           |           |
| Survey    | Mac(beta) |           |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+
| iBwave    | Windows / | Proprieta | Sim       | Sim / Não | 1,495     |
| Wi-Fi®    | Android   | rio       |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+
| TamoGraph | Windows   | Proprieta | Não       | Sim       | 899       |
| Site      |           | rio       |           |           |           |
| Survey    |           |           |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+
| VisiWave  | Windows   | Proprieta | Não       | Não       | 549       |
| Site      |           | rio       |           |           |           |
| Survey    |           |           |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+
| NetSpot   | Mac/      | Proprieta | Não       | Não       | 149 /     |
| WiFi Site |           | rio       |           |           | Versão    |
| Survey    | Windows   |           |           |           | gratuita  |
|           |           |           |           |           | para uso  |
|           |           |           |           |           | caseiro   |
|           |           |           |           |           | no        |
|           |           |           |           |           | windows   |
+-----------+-----------+-----------+-----------+-----------+-----------+
| Meritech  | Windows   | Proprieta | Não       | Não       | 495       |
| ISite     |           | rio       |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+
| Proposta  | GNU/Linux | Livre     | Sim       | Sim       | Grátis    |
| deste     |           |           |           |           |           |
| projeto   |           |           |           |           |           |
| de TCC    |           |           |           |           |           |
+-----------+-----------+-----------+-----------+-----------+-----------+

FONTE:
[[https://en.wikipedia.org/wiki/Comparison\_of\_wireless\_site\_survey\_applications]{.underline}](https://en.wikipedia.org/wiki/Comparison_of_wireless_site_survey_applications)

METODOLOGIA
===========

A seguir são destacados os principais passos que foram tomados para a
realização integral das especificações propostas deste TCC, seguindo o
método PDCA para iteração, controle e melhoria do processo de
desenvolvimento.

1.  Preparação e Projeto
    --------------------

    1.  Coleta das medições
        -------------------

> A primeira, e possivelmente, a mais importante etapa de
> desenvolvimento foi na decisão de como seria feita a coleta dos dados
> de sinais Wi-Fi, nesta fase foi decidido que estas informações seriam
> obtidas por meio de uma ferramenta livre do Sistema Operacional Linux,
> o *iwlist scannig*, antes outras abordagens foram testadas, mas devido
> às informações oferecidas pelo *iwlist* serem de melhor interpretação
> e análise este foi adotado para a coleta das medições. Para uma melhor
> análise da saída, foi necessária a utilização de um script com os
> filtros para descartar algumas informações de pouca ou nenhuma
> relevância para a condução do *survey*.

![](media/image24.png){width="6.197916666666667in"
height="2.6498523622047245in"}

exemplo de saída do iwlist (disponibilizado pelo pacote wireless-tools).

Visualização dos dados
----------------------

> Foram pesquisados métodos de visualização da intensidade do sinal
> *wireless*, tais como, por exemplo, mapas de calor (*heat map*),
> isolinhas (*countour line*) e gráficos de superfície (*surface plot*),
> e para esta aplicação foi adotado o mapa de calor utilizando uma
> biblioteca java para interação com o gnuplot por meio da interpolação
> dos dados coletados e devidamente filtrados gera o heatmap.

![](media/image17.png){width="6.302329396325459in"
height="3.7777777777777777in"}Heatmap gerado pelo gnuplot.

> As cores escolhidas aqui servem para representar maior e menor
> quantidade de sinal em uma determinada área, onde mais próximo da cor
> vermelha representa um sinal mais forte/quente o que significa que
> está mais perto ou recebendo uma maior intensidade de sinal do AP e
> quanto mais próximo de azul representa um sinal mais fraco/frio, o que
> significa que está mais distante ou sofre mais interferência na
> recepção do sinal. Com este Heatmap então é possível interpretar a
> imagem sobreposta a uma planta do local inspecionado ou avaliado em
> questão, e relatar possíveis falhas no posicionamento dos roteadores
> ou pontos de acesso sem fio e ainda sugerir um reposicionamento ou
> reajuste (ex.: mudar a frequência ou canal em que o ap trabalha) para
> os mesmos.
>
> Outra informação importante que pode ser observada pela imagem é que a
> diferença na coloração se dá em *decibel miliwatt* (dbm) e, muitas
> vezes, esses valores parecem ter uma pequena diferença entre si quando
> na verdade são ordens de grandeza. O decibel (dB) é uma unidade
> logarítmica que indica a proporção de uma quantidade física
> (geralmente energia ou intensidade) em relação a um nível de
> referência especificado ou implícito. Uma relação em decibels é igual
> a dez vezes o logaritmo de base 10 da razão entre duas quantidades de
> energia. Essa diferença pode ser vista na conversão abaixo onde o
> valor do sinal expresso por dbm é convertido em *miliwatt* (mW)
> pegando o maior e o menor valor da escala do gráfico acima:
>
> Fórmula para conversão de dbm para watt
>
> $P(W)\  = \ 1W\  \cdot \ 10(P(dBm)\ /\ 10)\ /\ 1000\  = \ 10((P(dBm) - \ 30)\ /\ 10)$

-   Maior valor -55 dBm (decibels-miliwatt) = 3.162×10\^-9 W (watts) ou
    > 0.000003162 (mW);

-   Menor valor -90 dBm (decibels-miliwatt) = 1.00×10\^-12 W (watts) ou
    > 0.000000001 (mW);

    1.  Implementação
        -------------

        1.  Interpretação dos dados coletados
            ---------------------------------

A medição da intensidade do sinal e outras características é realizada
através de serviços do sistema operacional GNU/Linux, utilizando o
*iwlist* *scannig* e GNUPLOT.

O *iwlist* é responsável pela coleta das informações. Explicação de uma
saída do *iwlist* como mostrada anteriormente:

-   Cell 01 - Address: 18:8B:9D:69:EF:F6 -\> Endereço MAC do Ponto de
    > Acesso sem fio;

-   Channel: 44 -\> O canal no qual o AP está atuando no momento da
    > medição;

-   Frequency: 5.22 GHz (Channel 44) -\> Frequência de transmissão que o
    > AP está utilizando;

-   Quality: 41 -\> O quanto o sinal recebido está mais forte que a
    > interferência observada, ou seja, neste caso a relação de sinal
    > para ruído (SNR) é de 41 vezes. Recentemente definido pelo IEEE
    > 802.11k como RSNI (*Received Signal to Noise Indicator*);

-   Signal level: -69 dBm -\> Intensidade de sinal recebida do
    > Transmissor, conhecido como RSSI (*Received Signal Strength
    > Indicator*) e mais recentemente definido pelo IEEE 802.11k como
    > RCPI (*Received Channel Power Indicator*);

-   Encryption key: on -\> Indica se o AP possui algum tipo de
    > criptografia ou não;

-   ESSID: \"wifi-alunos\" -\> Nome da rede anunciada pelo AP;

-   Bit Rates: 12 Mb/s; 18 Mb/s; 24 Mb/s; 36 Mb/s; 48 Mb/s -\> Taxas de
    > transmissão suportadas pelo Ponto de Acesso;

-   IE: IEEE 802.11i/WPA2 Version 1 -\> Indica o padrão de criptografia
    > utilizado;

Já o GNUPLOT faz uma interpolação dos dados passados para ele por meio
do software desenvolvido. Exemplo de saída demonstrado na figura Heatmap
gerado pelo gnuplot.

Durante a coleta dos dados para cada ponto de medição é marcada uma
posição na tela que representa a posição em escala na planta carregada
na interface, ou seja, o lugar que estiver marcado por um ponto no mapa
representa o local real em que o usuário se encontra em relação a planta
do local de avaliação.

Filtragem de dados da coleta
----------------------------

Imagem do arquivo gerado após filtrar informações relevantes da saída do
*iwlist*.

O script para filtrar do iwlist com as informações relevantes está
disponivel em
[[https://github.com/vinicius023/Wireless-Site-Survey/blob/master/WirelessSurveyTCC/filtra-iwlist.sh]{.underline}](https://github.com/vinicius023/Wireless-Site-Survey/blob/master/WirelessSurveyTCC/filtra-iwlist.sh),
os filtros escolhidos foram: qualidade (Quality), célula ou endereço MAC
(Cell), canal (Channel), frequência (Frequency), se o AP tem ou não
criptografia (Encryption), nome da rede (ESSID), taxas de bit (Bit
Rates), tipos de protocolos de segurança se o AP possuir (IEEE WPA's ou
WEP). Apesar de ter essas informações salvas, alguns dos filtros citados
acima como taxas de bits, se tem ou não criptografia, ou os tipos de
protocolo de segurança, não são tratados como opções para filtrar a
saída que gera o mapa de calor da coleta.

Representação do ambiente 
--------------------------

> Dado o problema de localização anteriormente citado, foi estipulado
> que o tamanho do JPanel que irá conter a planta-baixa, em um JLabel,
> do edifício tem um valor fixo, deste modo evitando problemas de escala
> em relação ao ambiente real. Se fosse possível alterar esse tamanho,
> os valores coletados em determinada posição com uma escala teriam que
> ser todos reajustados ao mudar o tamanho do JPanel. Para a
> representação do ambiente a ser avaliado, é utilizado uma imagem .jpg
> ou .png como entrada. Esta imagem é então carregada em um JLabel e
> exibida na interface gráfica para o usuário. É esperado que a entrada
> fornecida pelo usuário seja uma representação escalada da planta baixa
> do local, para melhor interpretação e localização na hora de conduzir
> o *survey.*

![](media/image26.png){width="6.299212598425197in"
height="3.4166666666666665in"}

Exemplo de representação da interface da aplicação.

Cada medição é registrada com a indicação (em uma interface gráfica) de
qual ponto do ambiente ela foi realizada.

![](media/image45.png){width="6.302329396325459in"
height="3.5416666666666665in"}

Imagem dos pontos de uma coleta sem sobreposição do heatmap.

Exibição gráfica dos dados
--------------------------

Por fim, o resultado final de todas as medições realizadas é apresentado
através de uma visualização gráfica. Devidamente calculada a
interpolação entre as medidas coletadas pelo iwlist e filtradas pelos
scripts bash desenvolvidos, somadas ao uso de um mapa de calor provido
pelo GNUPLOT, este resultado é exibido na Interface Gráfica da aplicação
separados por camadas. Analisando a cobertura e localização dos APs
Wi-Fi, pode-se observar a perda de intensidade (distância) e atenuação
do sinal (obstáculos) em seu percurso desde o AP Wi-Fi até determinada
medição (ALMERS et al., 2007; LENTZ, 2003; SANDEEP, 2008).

![](media/image28.png){width="6.302329396325459in"
height="3.5416666666666665in"}

Na imagem acima é possível notar as sobreposições de camadas, onde na
camada mais inferior é carregada uma planta-baixa do local de *survey*.
A segunda camada é onde o heatmap é plotado e a terceira e última camada
fica encarregada de exibir os pontos das coletas.

![heatmap\_intensidade.png](media/image37.png){width="6.302329396325459in"
height="4.486111111111111in"}

Imagem1: heatmap intensidade gerado pelo GNUPLOT

![saida\_intensidade\_LEMBRANCA.png](media/image42.png){width="6.25in"
height="4.166666666666667in"}

Imagem2: heatmap qualidade (SNR) para os primeiros testes

Testes e Ajustes
----------------

Durante e após a implementação do mecanismo de coleta de medições e
interface gráfica, os resultados obtidos foram ajustados, para que o
software, num processo de melhoria contínua, tivesse um aumento na
precisão da solução a ser apresentada.

![](media/image22.png){width="6.25in" height="4.166666666666667in"}

figura GradienteRoxo

Teste realizado no corredor do bloco A no segundo pavimento, a condução
deste teste foi feita em uma linha reta e os resultados aqui obtidos a
partir de um único ponto de acesso avaliado, os eixos x e y na verdade
representam o mesmo eixo, o valor deste gráfico está em indicar qual o
comportamento do plot para uma certa quantidade de dados coletados (em
uma breve análise é notável que ao aumentar a distância no eixo x ou y,
que são o mesmo, a intensidade do sinal decai, e as manchas escuras no
meio do gráfico representam fontes de interferência do sinal que
ocorreram durante a medição).

![](media/image41.png){width="6.302329396325459in"
height="4.486111111111111in"}

Imagem de teste para ajuste das cores do GNUPLOT

Inicialmente, os heatmaps eram gerados com as cores originais do gnuplot
(gradiente roxo para amarelo da figura GradienteRoxo). Para uma melhor
interpretação, foram substituídas pelo esquema de cores providos pelo
Matlab (gradiente azul para vermelho), que também traz uma lembrança de
quente e frio que, por sua vez, remete à distância (longe ou perto) da
fonte de radiação de sinal.

Outros tratamentos necessários foram um corte e um flip na imagem gerada
pelo gnuplot. O corte foi vital, pois os valores e os eixos que
apareciam no plot não encaixavam bem na exibição da interface. O flip
foi devido ao fator dos pontos serem coletados em uma tela onde os
valores de x cresciam da esquerda para direita e de y cresciam de cima
para baixo, já o GNUPLOT força o eixo y crescer de baixo para cima.

![](media/image23.png){width="6.302329396325459in"
height="3.5416666666666665in"}

Durante o desenvolvimento da interface surgiu a necessidade de criar uma
área específica para a exibição gráfica dos mapas e condução do *survey*
(área em azul), porém, no início quando os pontos eram coletados só
havia um evento que capturava o clique do mouse e este evento pegava a
posição em qualquer área do JFrame principal (soma das áreas azul,
laranja, verde e menu superior), isso gerava o problema de pontos fora
da medição atrapalhando ainda os valores gerados para o GNUPLOT deixando
fora de escala o heatmap. Esse problema logo foi resolvido, a questão
estava a quem o evento do mouse era atribuído.

Com a solução do problema dos pontos fora do mapa, teve início então o
desenvolvimento de um método para carregar o mapa no JLabel sem que a
imagem da planta-baixa fosse cortada, para isso ela é carregada e
redimensionada em um novo ícone/imagem, mantendo a integridade do
arquivo original e proporcionando a escala necessária para a medição.

![](media/image38.png){width="6.302329396325459in"
height="2.861111111111111in"}

![](media/image40.png){width="6.126189851268592in"
height="3.662632327209099in"}

Além do problema de escala encontrado, surgiu uma limitação para o
tamanho do JPanel em um valor máximo de alcance dos eixos x e y que o
GNUPLOT proporciona, sendo esses valores 1000 por 1000 (x e y menores ou
iguais a 1000) e para manter a escala da planta com a escala do heatmap
o JPanel teve sua resolução fixa em 1000x600 e toda imagem carregada
nele segue esse mesmo valor.

A princípio houve a tentativa de gerar o mapa de calor utilizando a
biblioteca java AWT, mas devido à facilidade que o GNUPLOT proporcionou,
ele foi adotado como o método principal para gerar o heatmap.

Já com tudo devidamente ajustado em relação às medidas e exibição
gráfica do heatmap surgiu outro problema: ao atualizar a imagem do
GNUPLOT os pontos da medição não ficavam em exibição na interface,
podendo deixar o usuário perdido durante a condução do *survey*, então
alguns testes com o plot dos pontos gerados pelo GNUPLOT foram feitos,
porém não foram satisfatórios. A partir daí, outra metodologia foi
adotada para tentar solucionar este problema: threads foram
implementadas para cada processo, uma responsável por coletar os dados,
outra por gerar o heatmap, e outra para redesenhar os pontos usando a
biblioteca Graphics2D do AWT, sendo as duas últimas um laço de repetição
sempre tentando atualizar suas respectivas imagens (Heatmap e Pontos da
medição). A atualização dessas informações é de tempos em tempos pois
existe uma demora ao tentar gerar um mapa de calor e desenhar os pontos
da coleta toda vez que ocorrer o evento de clique, por isso essas
atualizações são feitas por Threads separadas evitando que o usuário
tenha que esperar muito tempo parado no mesmo lugar até que todos os
cálculos tenham sido concluído.

Fazendo alguns testes com iwlist percebeu-se que existe uma demora para
o retorno de sua saída de acordo com quantidade de APs. É possível
tentar filtrar pelo nome da rede Wi-Fi (ESSID) diretamente no comando
passando por parâmetros no bash, mas de acordo com o manual do iwlist
alguns drivers podem ignorar esta opção, o que ocorreu com o hardware
usado nos testes. Devido a isso, foi elaborado então um script bash que
faz essa função com a adição de opção para filtrar a saída por AP
específico. ex: sudo iwlist wlp2s0 scanning essid \"adm-ifmg\". (Nem
sempre é chamado wlp2s0. Neste caso é o nome da interface wireless da
placa de rede do notebook usado para os testes).

Experimentos de validação 
--------------------------

![](media/image12.png){width="6.302329396325459in"
height="3.0555555555555554in"}

> Para validação da aplicação, um teste de grande escala foi realizado
> no bloco C - terceiro pavimento do Instituto Federal de Minas Gerais -
> Campus Formiga como seguem as imagens abaixo com a execução dos passos
> do fluxograma.
>
> ![](media/image36.png){width="6.302329396325459in"
> height="3.5416666666666665in"}
>
> Coleta parcial dos pontos.

![](media/image35.png){width="6.302329396325459in"
height="3.5416666666666665in"}

Coleta finalizada dos pontos.

![](media/image43.png){width="6.152230971128609in"
height="3.5520833333333335in"}

Heatmap gerado a partir das medições anteriores.

![](media/image44.png){width="6.302329396325459in"
height="3.5416666666666665in"}

Teste realizado em uma residência.

Materiais
---------

Notebook Samsung ativ book 6 np670z5e-xd1br:

-   Processador - Intel(R) Core(™) i5-3230M CPU 2.60GHz

-   Memória RAM - 8GB DDR3 single channel

-   Interface de rede sem fio - Centrino Advanced-N 6235

    -   Streams TX/RX 2x2

    -   Bandas 2.4 GHz/ 5GHz

    -   Velocidade máxima 300 Mbps

    -   Padrões suportados Wi-Fi 802.11 a/b/g/n

    -   Conformidade PCI, CISP, FIPS, FISMA

    -   Bluetooth integrado Sim

RESULTADOS E ANÁLISE
====================

O programa compilado e seu código-fonte podem ser obtidos gratuitamente
no repositório
[[https://github.com/vinicius023/Wireless-Site-Survey]{.underline}](https://github.com/vinicius023/Wireless-Site-Survey).
Abaixo são apresentados e discutidos os resultados obtidos com o
software construído.

Cenário 1 - pavimento de um edifício
------------------------------------

![](media/image25.png){width="6.302329396325459in"
height="3.5416666666666665in"}

Imagem Intesidade da rede wifi-alunos bloco c terceiro pavimento.

Os resultados obtidos pelo teste de validação são apresentados na imagem
acima. Uma observação deve ser feita: não foram realizadas coletas de
pontos dentro dos banheiros masculino e feminino.

![](media/image16.png){width="3.0in" height="1.96875in"}

> Ao observarmos o trecho cortado da imagem é possível notar que existe
> uma boa intensidade de sinal sendo propagada na sala da direita,
> enquanto na da esquerda nem tanto.
>
> Vale lembrar que, na escala de cores, a cor azul não representa
> ausência completa de sinal, pois o local marcado com um ponto preto
> representa um AP que mesmo estando fora da sala é capaz de fornecer
> certa qualidade de sinal. Isso pode ocorrer pelo fato de as reflexões,
> difrações e dispersões da propagação do Wi-Fi serem favoráveis àquela
> posição. Também é válido ressaltar que a parede entre o ponto de
> acesso e a sala possui um seguimento de janelas no topo bem em frente
> ao roteador, melhorando assim a irradiação do sinal para aquele local.

![](media/image13.png){width="3.03125in" height="1.96875in"}

O efeito anterior era esperado para a sala em frente ao outro ponto de
acesso, porém próximo a esta região encontra-se um elevador - ao lado do
AP - o que pode causar grande interferência na propagação do sinal.
Outro ponto que sofre bastante interferência é a sala menor no canto
direito onde há duas paredes grossas e com grande concentração de cabos
de energia.

![](media/image39.png){width="2.8854166666666665in" height="3.15625in"}

Analisando o corte acima é possível reparar que, para a rede
"wi-fi-alunos" nesse ponto de acesso, a intensidade do sinal não é tão
forte quanto nos outros locais da avaliação. Neste caso, era ainda mais
esperado que o mesmo que ocorre no primeiro corte acontecesse também,
porém a localização do AP nesta parede está exatamente em frente a uma
coluna de concreto responsável pela sustentação do bloco C.

Cenário 2 - uma residência
--------------------------

![](media/image14.png){width="6.188689851268592in"
height="2.8055391513560806in"}

Analisando de forma geral a dispersão do sinal em uma residência, é
possível notar uma perda maior em pontos mais escuros, como o cômodo do
meio que, além de estar mais afastado do AP, está próximo a motores como
de geladeira e freezer, sofrendo assim uma perda maior ainda que a uma
distância menor do último quarto que possui pontos com melhor
intensidade de sinal. Isso acontece porque existe uma janela de
aproximadamente 2 m x 1,5 m aberta no cômodo mais a esquerda com visão
direta ao ponto de acesso.

![](media/image21.png){width="2.8645833333333335in"
height="2.2916666666666665in"}

Averiguando os resultados obtidos de uma medição realizada apenas no
primeiro cômodo da residência (corte da figura), é importante ressaltar
que, próximos à área azul clara, onde o sinal está mais fraco, havia
duas pessoas entre o AP e o notebook. Já na região próxima à janela da
direita, havia uma pessoa sentada em uma cadeira. Isso mostra que o
corpo humano também pode interferir na transmissão do sinal Wi-Fi, pois
a composição orgânica do corpo age como barreira.

CONSIDERAÇÕES FINAIS
====================

Durante o desenvolvimento do software de avaliação de sinal WiFi sem
limitações na coleta dos dados e FOSS para o SO linux, conhecimentos de
diversas áreas foram adquiridos, áreas como, operações com scripts bash
no SO linux, um pouco de desenvolvimento de interfaces java, interação
da linguagem java com outros programas do SO, conhecimento e um certo
nível de entendimento a respeito de comunicação sem fio em redes para
uma melhor interpretação dos resultados da ferramenta desenvolvida,
entre outras áreas. Ao analisar os resultados no tópico anterior, foi
possível aferir que o software desenvolvido não deixa a desejar quando
se trata do objetivo principal de um *site survey.* Algumas
funcionalidades ainda podem ser adicionadas, outras melhor ajustadas,
mas o cerne do programa está de acordo com o previsto. Para trabalhos
futuros ficam o desenvolvimento de uma interface mais amigável, a
possibilidade da criação de projetos, viabilizar uma forma de
identificar melhor quais redes e aps estão disponíveis, pois a princípio
considerasse que o usuário já tenha este conhecimento. A aplicação
desenvolvida tem grande potencial, por ela ser FOSS a comunidade tem
muito a contribuir em seus ajustes e melhorias como citado
anteriormente.

REFERÊNCIAS BIBLIOGRÁFICAS
==========================

ALMERS, P., BONEK, E., BURR, A., CZINK, N., DEBBAH, M., DEGLI-ESPOSTI,
V., OZCELIK, H. Survey of channel and radio propagation models for
wireless MIMO systems. In: Eurasip Journal on Wireless Communications
and Networking, 2007.

DOS SANTOS, ALEF ALVES et al. Site Survey--Uso e Aplicação. 2012.

GEIER, J. Site survey tools simplify 802.11 deployments. 2002.
Disponível em: \<http://www.
wifiplanet.com/tutorials/article.php/953661\>. Acesso em: 10 mar. 2006.

GEIER, Jim. RF site survey steps. 2002. Disponível em:
\<http://www.wi-fiplanet.com/ tutorials/article.php/1116311\>. Acesso
em: 10 mar. 2006.

IEEE 802.11-2016 - IEEE Standard for Information
technology\--Telecommunications and information exchange between systems
Local and metropolitan area networks\--Specific requirements - Part 11:
Wireless LAN Medium Access Control (MAC) and Physical Layer (PHY)
Specifications. In: IEEE Standards Association, 1999.

IEEE 802.11a-1999. IEEE Standard for Telecommunications and Information
Exchange Between Systems - LAN/MAN Specific Requirements - Part 11:
Wireless Medium Access Control (MAC) and physical layer (PHY)
specifications: High Speed Physical Layer in the 5 GHz band. In: IEEE
Standards Association, 1999.

IEEE 802.11ac-2013. IEEE Standard for Information
technology\--Telecommunications and information exchange between
systems---Local and metropolitan area networks\--Specific
requirements\--Part 11: Wireless LAN Medium Access Control (MAC) and
Physical Layer (PHY) Specifications\--Amendment 4: Enhancements for Very
High Throughput for Operation in Bands below 6 GHz. In: IEEE Standards
Association, 2013.

IEEE 802.11b-1999. IEEE Standard for Information Technology -
Telecommunications and information exchange between systems - Local and
Metropolitan networks - Specific requirements - Part 11: Wireless LAN
Medium Access Control (MAC) and Physical Layer (PHY) specifications:
Higher Speed Physical Layer (PHY) Extension in the 2.4 GHz band. In:
IEEE Standards Association, 1999.

IEEE 802.11g-2003. IEEE Standard for Information technology - Local and
metropolitan area networks\-- Specific requirements\-- Part 11: Wireless
LAN Medium Access Control (MAC) and Physical Layer (PHY) Specifications:
Further Higher Data Rate Extension in the 2.4 GHz Band. In: IEEE
Standards Association, 2003.

IEEE 802.11k-2008. IEEE Standard for Information technology\-- Local and
metropolitan area networks\-- Specific requirements\-- Part 11: Wireless
LAN Medium Access Control (MAC)and Physical Layer (PHY) Specifications
Amendment 1: Radio Resource Measurement of Wireless LANs. In: IEEE
Standards Association, 2008.

IEEE 802.11n-2009. IEEE Standard for Information technology - Local and
metropolitan area networks - Specific requirements - Part 11: Wireless
LAN Medium Access Control (MAC)and Physical Layer (PHY) Specifications
Amendment 5: Enhancements for Higher Throughput. In: IEEE Standards
Association, 2009.

JARDIM, F. de M. Guia profissional de redes Wireless:
Voip/Wi-fi/Bluetooth/Wimax/Infravermelho/Skype. Digerati/Universo dos
Livros-ISBN, 2005.

LENTZ, C. 802.11b Wireless Network Visualization and Radiowave
Propagation Modeling. Relatório Técnico, Dartmouth Computer Science,
2003.

RODRIGUES, William Carlos de J.; DOS SANTOS, Ezequiel Ferreira. Site
survey: mapeamento, detecção de vulnerabilidades e análise de sinal de
redes sem fio. Exacta, v. 5, n. 1, p. 69-78, 2007.

SANDEEP, A. R. et al. Wireless network visualization and indoor
empirical propagation model for a campus wi-fi network. World Academy of
Science, Engineering and Technology, v. 42, p. 730-734, 2008.

SANTOS, Ezequiel Ferreira Santos. Site survey: mapeamento, detecção de
vulnerabilidades e análise de sinal de redes sem fio. Exacta (São Paulo.
Impresso), v. 5, p. 69-78, 2007.

SONG, Shuang; ISSAC, Biju. Analysis of Wifi and Wimax and Wireless
Network Coexistence. arXiv preprint arXiv:1412.0721, 2014.

WIRELESS STANDARDS 802.11a, 802.11b/g/n, AND 802.11ac. Disponível em:
\<https://www.lifewire.com/wireless-standards-802-11a-802-11b-g-n-and-802-11ac-816553\>.
Acesso em: 29 de sep. 2017.

APÊNDICES
=========

APÊNDICE A - BLA BLA BLA
------------------------

... algo importante mas grande demais para caber ao longo do texto.
