# Introdução

Wireless Survey é uma forma de inspeção de rede sem fio através da análise da intensidade de sinal Wi-Fi de determinada área ou WLAN específica. A medição é feita pelo canal da banda de frequência, de acordo com o padrão Wi-Fi considerado (2.4 GHz no caso do IEEE 802.11 b/g/n ou 5 GHz no 802.11 a/ac).
Com os dados coletados por uma ferramenta de wireless survey é possível analisar um melhor posicionamento para os pontos de acesso (APs) à rede sem fio levando em conta os locais de maior interferência de sinal observados. Também é possível verificar se é necessário o acréscimo do número de APs. O sinal Wi-Fi pode sofrer interferência de qualquer produto capaz de emitir sinais de RF na mesma faixa de frequência do ponto de acesso que o emite. Geralmente isso ocorre quando algum equipamento também está em uma frequência de 2.4 GHz (ou 5.8 GHz, conforme o caso).
A aplicação deste método de análise é cabível quando é notado que a rede Wi-Fi em uso apresenta baixa qualidade no canal e/ou queda de desempenho da rede, sem que esta seja causada pelo uso massivo de usuários da rede em questão. O wireless survey também é muito utilizado no planejamento de uma nova rede Wi-Fi, por exemplo, evitando-se locais com preexistência de APs trabalhando na mesma frequência.
Nas seções a seguir serão apresentados os objetivos e justificativas deste projeto, bem como a metodologia para o desenvolvimento de uma aplicação wireless survey gratuita e de código fonte aberto, com suporte ao sistema operacional GNU/Linux.

## Motivação

## Objetivos

### Objetivo geral

Apresentação do objetivo geral.

### Objetivos específicos

- objetivo 1
- objetivo 2
- objetivo 3

<!-- 
Isto é um comentário, mesma sintaxe do HTML. Para conhecer a sintaxe 
do limarka consulte: https://github.com/abntex/limarka/wiki/Sintaxe 
-->

# Como utilizar recursos do limarka

**Consulte o wiki do projeto**: https://github.com/abntex/limarka/wiki

Cada capítulo inicia automaticamente em página ímpar (em conformidade com as Normas). Por isso que existem várias páginas em branco nesse documento.

## Como citar e referenciar

O arquivo de referências é configurado em "configuracao.pdf", utilize-o
para gerenciar suas referências.

Veja um exemplo de citação direta e referenciação a seguir:

> A ‘norma’ 6023:2000 (2) é complicada e cheia de inconsistências. Jamais será
possível gerar um estilo bibtex totalmente consistente com a ‘norma’, até porque
nem a ‘norma’ é compatível com ela mesma. Um bom estilo bibliográfico deve
ter uma linha lógica para formatação de referências. Assim, com alguns poucos
exemplos, qualquer pessoa poderia deduzir os casos omissos. Nesse sentido, a
‘norma’ 6023 trafega pela contra-mão. É quase impossível deduzir sua linha lógica.
O problema mais grave, no entanto, fica pela maneira de organizar nomes. A ABNT
quebrou o sobrenome em duas partes. Normalmente se fala apenas em “*last name*”,
mas agora temos o “*last last name*” graças à ABNT. \cite[p. 5]{abntex2cite}.

Consulte o documento \citeonline{abntex2cite} para conhecer como referenciar os
conteúdos.

## Como inserir imagens

Por exemplo, a Figura \ref{passaro} mostra um pássaro que possui as cores da bandeira do Brasil. 

<!--
Para referenciar essa figura no texto utilize: Figura \ref{passaro} ou \autoref{passaro}
-->

![Pássaro com as cores da bandeira do Brasil](imagens/passaro.jpg){#passaro width=40%}

Fonte: \citeonline{limarka}

As imagens são inseridas o mais próximo possível do texto que as referenciam.
